@echo off
setlocal
set "ROOT=%~dp0"
if not exist "%ROOT%index.html" (
  echo Could not find index.html. Keep this launcher beside the NASTOR_AI_STUDIO files.
  pause
  exit /b 1
)
where node >nul 2>nul
if %errorlevel%==0 (
  start "NASTOR Bridge" /min cmd /c "node ""%ROOT%desktop-bridge\server.js"" > ""%ROOT%desktop-bridge\bridge.log"" 2>&1"
) else (
  echo Node.js not found. Dashboard will still open; bridge status will remain offline.
)
start "" "%ROOT%index.html"
endlocal
