#!/bin/bash
# Double-click this file on macOS to start the local bridge (when Node.js exists)
# and open the NASTOR AI STUDIO dashboard.

ROOT="$(cd "$(dirname "$0")" && pwd)"
BRIDGE="$ROOT/desktop-bridge/server.js"

if [ ! -f "$ROOT/index.html" ]; then
  echo "Could not find index.html. Keep this launcher beside the NASTOR_AI_STUDIO files."
  read -r -p "Press Return to close..."
  exit 1
fi

if command -v node >/dev/null 2>&1; then
  if ! curl -fsS "http://127.0.0.1:4317/status" >/dev/null 2>&1; then
    nohup node "$BRIDGE" > "$ROOT/desktop-bridge/bridge.log" 2>&1 &
    echo $! > "$ROOT/desktop-bridge/bridge.pid"
    sleep 1
  fi
  echo "NASTOR desktop bridge started (or was already running)."
else
  echo "Node.js was not found. The dashboard will still open; MIDI export and local tools work without the bridge."
fi

open "$ROOT/index.html"
echo "NASTOR AI STUDIO opened in your default browser."
