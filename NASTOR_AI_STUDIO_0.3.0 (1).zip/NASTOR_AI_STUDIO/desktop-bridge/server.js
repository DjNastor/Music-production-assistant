'use strict';
// Local-only read-only status bridge. No shell, mouse or keyboard commands are exposed.
const http = require('http');
const PORT = 4317;
const HOST = '127.0.0.1';

const server = http.createServer((req, res) => {
  // The dashboard can be opened as a local file (Origin: null) or from localhost.
  const origin = req.headers.origin;
  if (!origin || origin === 'null' || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
  }
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.writeHead(204);
    return res.end();
  }

  if (req.method === 'GET' && req.url === '/status') {
    res.writeHead(200);
    return res.end(JSON.stringify({
      bridge: true,
      flStudio: false,
      product: 'NASTOR AI STUDIO',
      version: '0.2.0',
      message: 'The local desktop helper is running. Direct FL Studio control is not implemented in this build.'
    }));
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.on('error', error => {
  if (error.code === 'EADDRINUSE') {
    console.error('Port 4317 is already in use. Another bridge may already be running.');
  } else {
    console.error('Bridge error:', error.message);
  }
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  console.log(`NASTOR AI STUDIO bridge listening on http://${HOST}:${PORT}`);
  console.log('Status endpoint: /status (read-only)');
});
