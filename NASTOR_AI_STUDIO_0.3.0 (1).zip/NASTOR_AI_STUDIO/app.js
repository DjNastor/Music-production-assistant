'use strict';

const STORAGE = { projects: 'nastorStudio.projects.v2', tasks: 'nastorStudio.tasks.v2' };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const starterProjects = [
  { id: 'p-lost', name: 'Lost in a Dream', artist: 'DJ Nastor', genre: 'Deep Afro House', status: 'In progress', updated: '2026-11-25', initials: 'LD' },
  { id: 'p-studio', name: 'Lukulu Studio Session', artist: 'Lukulu Recordings', genre: 'Sound design', status: 'Idea', updated: '2026-11-24', initials: 'LS' },
  { id: 'p-chapter', name: 'New Chapter', artist: 'DJ Nastor', genre: 'Afro House', status: 'In progress', updated: '2026-11-22', initials: 'NC' }
];
const starterTasks = [
  { id: 't1', text: 'Choose the main chord progression', done: false },
  { id: 't2', text: 'Build the kick and bass relationship', done: false },
  { id: 't3', text: 'Add organic percussion layers', done: false },
  { id: 't4', text: 'Arrange an intro and first drop', done: false }
];

function loadState(key, fallback) {
  try { const value = JSON.parse(localStorage.getItem(key)); return Array.isArray(value) ? value : fallback; }
  catch (_) { return fallback; }
}
let projects = loadState(STORAGE.projects, starterProjects);
let tasks = loadState(STORAGE.tasks, starterTasks);
function saveState() {
  try { localStorage.setItem(STORAGE.projects, JSON.stringify(projects)); localStorage.setItem(STORAGE.tasks, JSON.stringify(tasks)); }
  catch (_) { notify('Browser storage is unavailable. Export a backup to keep your changes.'); }
  updateDashboard();
}
function notify(message) {
  const toast = $('#toast'); if (!toast) return;
  toast.textContent = message; toast.classList.add('show');
  clearTimeout(notify.timer); notify.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}

const pageTitles = { dashboard: 'Dashboard', production: 'Production Lab', projects: 'Projects', planner: 'Session Planner', flstudio: 'FL Studio Link', assistant: 'Studio Assistant' };
function go(page) {
  $$('.page').forEach(section => section.classList.toggle('active', section.id === page));
  $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.page === page));
  $('#page-title').textContent = pageTitles[page] || 'Studio';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
$$('.nav-item').forEach(button => button.addEventListener('click', () => go(button.dataset.page)));
$$('[data-go]').forEach(button => button.addEventListener('click', () => go(button.dataset.go)));

function dateLabel() {
  const now = new Date();
  return now.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' }).toUpperCase();
}
$('#today-label').textContent = dateLabel();

function statusClass(status) { return status === 'Complete' ? 'Complete' : status === 'Idea' ? 'Idea' : 'In progress'; }
function projectMarkup(project, index, compact = false) {
  const initials = project.initials || project.name.split(/\s+/).slice(0, 2).map(word => word[0]).join('').toUpperCase();
  if (compact) return `<div class="recent-row"><div class="project-cover cover-${index % 3}">${escapeHTML(initials)}</div><div class="recent-meta"><b>${escapeHTML(project.name)}</b><small>${escapeHTML(project.artist || 'DJ Nastor')} · ${escapeHTML(project.genre || 'Afro House')}</small></div><span class="status-chip">${escapeHTML(project.status || 'Idea')}</span></div>`;
  return `<article class="panel project-tile"><div class="project-tile-art art-${index % 3}"><span>${escapeHTML(initials)}</span></div><div class="project-tile-content"><h3>${escapeHTML(project.name)}</h3><p>${escapeHTML(project.artist || 'DJ Nastor')} · ${escapeHTML(project.genre || 'Afro House')}</p><div class="project-tile-bottom"><small>UPDATED ${escapeHTML(project.updated || 'JUST NOW')}</small><div class="project-actions"><button class="mini-action" data-project-action="advance" data-id="${escapeHTML(project.id)}">Next status</button><button class="mini-action" data-project-action="delete" data-id="${escapeHTML(project.id)}" aria-label="Delete ${escapeHTML(project.name)}">Delete</button></div></div></div></article>`;
}
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function drawProjects() {
  $('#project-list').innerHTML = projects.length ? projects.map((project, index) => projectMarkup(project, index)).join('') : '<div class="empty-state">No projects yet. Create your first production project to get started.</div>';
  $('#recent-projects').innerHTML = projects.slice(0, 3).map((project, index) => projectMarkup(project, index, true)).join('') || '<div class="empty-state">Your new projects will appear here.</div>';
  $('#project-summary').textContent = `${projects.length} saved project${projects.length === 1 ? '' : 's'}`;
}
function updateDashboard() {
  $('#project-count').textContent = String(projects.length).padStart(2, '0');
  $('#task-count').textContent = String(tasks.filter(task => !task.done).length).padStart(2, '0');
  drawProjects(); drawTasks();
}
$('#new-project').addEventListener('click', () => {
  const name = window.prompt('What is the name of your new production project?');
  if (!name || !name.trim()) return;
  const cleanName = name.trim().slice(0, 70);
  projects.unshift({ id: `p-${Date.now()}`, name: cleanName, artist: 'DJ Nastor', genre: 'Afro House', status: 'Idea', updated: new Date().toISOString().slice(0, 10), initials: cleanName.split(/\s+/).slice(0, 2).map(word => word[0]).join('').toUpperCase() });
  saveState(); notify('Project created and saved.');
});
$('#project-list').addEventListener('click', event => {
  const button = event.target.closest('[data-project-action]'); if (!button) return;
  const index = projects.findIndex(project => project.id === button.dataset.id); if (index < 0) return;
  if (button.dataset.projectAction === 'delete') {
    if (!window.confirm(`Delete “${projects[index].name}” from this browser?`)) return;
    projects.splice(index, 1); notify('Project deleted.');
  } else {
    const states = ['Idea', 'In progress', 'Complete'];
    projects[index].status = states[(states.indexOf(projects[index].status) + 1) % states.length];
    projects[index].updated = new Date().toISOString().slice(0, 10); notify(`Status changed to ${projects[index].status}.`);
  }
  saveState();
});
$('#export-projects').addEventListener('click', () => downloadBlob(new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), projects, tasks }, null, 2)], { type: 'application/json' }), 'nastor-studio-backup.json'));
$('#import-projects').addEventListener('click', () => $('#backup-file').click());
$('#backup-file').addEventListener('change', async event => {
  const file = event.target.files && event.target.files[0]; if (!file) return;
  try {
    const backup = JSON.parse(await file.text());
    if (!backup || !Array.isArray(backup.projects) || !Array.isArray(backup.tasks)) throw new Error('This file does not look like a NASTOR Studio backup.');
    if (!window.confirm(`Import ${backup.projects.length} project(s) and ${backup.tasks.length} task(s)? This replaces the current browser workspace.`)) return;
    projects = backup.projects.filter(item => item && typeof item.name === 'string').map((item, index) => ({ id: String(item.id || `import-p-${Date.now()}-${index}`), name: item.name.slice(0, 70), artist: String(item.artist || 'DJ Nastor'), genre: String(item.genre || 'Afro House'), status: ['Idea','In progress','Complete'].includes(item.status) ? item.status : 'Idea', updated: String(item.updated || new Date().toISOString().slice(0, 10)), initials: String(item.initials || item.name.slice(0, 2)).slice(0, 2) }));
    tasks = backup.tasks.filter(item => item && typeof item.text === 'string').map((item, index) => ({ id: String(item.id || `import-t-${Date.now()}-${index}`), text: item.text.slice(0, 90), done: Boolean(item.done) }));
    saveState(); notify('Workspace backup imported.');
  } catch (error) { notify(error.message || 'Could not read this backup.'); }
  finally { event.target.value = ''; }
});

function drawTasks() {
  const done = tasks.filter(task => task.done).length;
  $('#task-progress').textContent = `${done} / ${tasks.length}`;
  $('#progress-fill').style.width = tasks.length ? `${done / tasks.length * 100}%` : '0%';
  $('#task-list').innerHTML = tasks.length ? tasks.map(task => `<div class="task-row ${task.done ? 'done' : ''}"><input type="checkbox" data-task-check="${escapeHTML(task.id)}" ${task.done ? 'checked' : ''} aria-label="Mark ${escapeHTML(task.text)} complete"><span>${escapeHTML(task.text)}</span><button class="task-delete" data-task-delete="${escapeHTML(task.id)}" aria-label="Delete task">×</button></div>`).join('') : '<div class="empty-state">Your session checklist is clear. Add a task above.</div>';
}
$('#task-form').addEventListener('submit', event => {
  event.preventDefault(); const input = $('#task-input'); const text = input.value.trim(); if (!text) return;
  tasks.push({ id: `t-${Date.now()}`, text: text.slice(0, 90), done: false }); input.value = ''; saveState(); notify('Task added to your session.');
});
$('#task-list').addEventListener('change', event => {
  const checkbox = event.target.closest('[data-task-check]'); if (!checkbox) return;
  const task = tasks.find(item => item.id === checkbox.dataset.taskCheck); if (task) task.done = checkbox.checked; saveState();
});
$('#task-list').addEventListener('click', event => {
  const button = event.target.closest('[data-task-delete]'); if (!button) return;
  tasks = tasks.filter(task => task.id !== button.dataset.taskDelete); saveState(); notify('Task removed.');
});

// Harmony generation: diatonic chord qualities are calculated from the selected major scale.
const NOTE_NAMES = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
const KEY_PC = { C: 0, Db: 1, D: 2, Eb: 3, E: 4, F: 5, Gb: 6, G: 7, Ab: 8, A: 9, Bb: 10, B: 11 };
const MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11];
const ROMANS = ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii°'];
function selectedHarmony() {
  const root = KEY_PC[$('#key').value] ?? 9;
  const degrees = $('#progression').value.split(',').map(Number);
  const voicing = $('#voicing').value;
  const chords = degrees.map((degree, index) => {
    const scaleIndex = degree - 1;
    const base = [0, 2, 4].map(step => MAJOR_SCALE[(scaleIndex + step) % 7] + (scaleIndex + step >= 7 ? 12 : 0));
    const relative = [base[0], base[1], base[2]];
    const intervals = relative.map((value, i) => (value - relative[0] + 12) % 12);
    const quality = intervals[1] === 3 ? (intervals[2] === 6 ? 'dim' : 'min') : 'maj';
    let semitones = relative.map(value => root + value);
    if (voicing === 'open') semitones = [semitones[0], semitones[2] + 12, semitones[1] + 12];
    if (voicing === 'seventh') { const seventhDegree = scaleIndex + 6; semitones.push(root + MAJOR_SCALE[seventhDegree % 7] + (seventhDegree >= 7 ? 12 : 0)); }
    semitones = semitones.map(value => 60 + value);
    const pitchNames = semitones.map(value => NOTE_NAMES[value % 12]);
    return { degree, roman: ROMANS[scaleIndex], quality, rootName: NOTE_NAMES[(root + MAJOR_SCALE[scaleIndex]) % 12], notes: pitchNames, midi: semitones, rootMidi: 48 + root + MAJOR_SCALE[scaleIndex] };
  });
  return { chords, root, voicing, bars: Number($('#bars').value), tempo: Number($('#tempo').value), groove: $('#groove').value };
}
function chordLabel(chord) { return `${chord.rootName}${chord.quality === 'min' ? 'm' : chord.quality === 'dim' ? '°' : ''}`; }
function renderHarmony() {
  const data = selectedHarmony();
  $('#chord-preview').innerHTML = data.chords.map((chord, index) => `<div class="chord-card"><b>${chordLabel(chord)}</b><small>${chord.notes.join(' · ')}</small><em>${chord.roman} · ${index + 1}</em></div>`).join('');
  $('#key-summary').textContent = `${$('#key').value} · ${data.tempo} BPM · ${data.voicing} voicing`;
  const rootMidi = 60 + data.root;
  const keyboard = Array.from({ length: 14 }, (_, index) => {
    const midi = 60 + index;
    const active = data.chords.some(chord => chord.midi.some(note => note % 12 === midi % 12));
    const black = [1, 3, 6, 8, 10].includes(midi % 12);
    return `<span class="key-note ${active ? 'active' : ''} ${black ? 'black' : ''}" title="${NOTE_NAMES[midi % 12]}"></span>`;
  }).join('');
  $('#keyboard-preview').innerHTML = keyboard;
}
['key', 'progression', 'bars', 'voicing', 'groove'].forEach(id => $(`#${id}`).addEventListener('change', renderHarmony));
$('#tempo').addEventListener('input', () => { $('#tempo-value').innerHTML = `${$('#tempo').value} <small>BPM</small>`; renderHarmony(); });
renderHarmony();

// MIDI file writer (Standard MIDI File format 1, separate chord, bass and drum tracks).
function variableLength(value) {
  let buffer = value & 0x7f; const bytes = [];
  while ((value >>= 7)) { buffer <<= 8; buffer |= ((value & 0x7f) | 0x80); }
  while (true) { bytes.push(buffer & 0xff); if (buffer & 0x80) buffer >>= 8; else break; }
  return bytes;
}
function textMeta(text) { const bytes = [...text].map(character => character.charCodeAt(0)); return [0xff, 0x03, ...variableLength(bytes.length), ...bytes]; }
function makeTrack(events, trackName, includeTempo, tempo) {
  const all = [{ tick: 0, priority: -2, bytes: textMeta(trackName) }];
  if (includeTempo) {
    const mpqn = Math.round(60000000 / tempo);
    all.push({ tick: 0, priority: -1, bytes: [0xff, 0x51, 0x03, (mpqn >> 16) & 255, (mpqn >> 8) & 255, mpqn & 255] });
    all.push({ tick: 0, priority: 0, bytes: [0xff, 0x58, 0x04, 4, 2, 24, 8] });
  }
  all.push(...events); all.sort((a, b) => a.tick - b.tick || a.priority - b.priority);
  let previousTick = 0; const trackBytes = [];
  for (const event of all) { trackBytes.push(...variableLength(event.tick - previousTick), ...event.bytes); previousTick = event.tick; }
  trackBytes.push(0, 0xff, 0x2f, 0x00);
  return [0x4d, 0x54, 0x72, 0x6b, (trackBytes.length >>> 24) & 255, (trackBytes.length >>> 16) & 255, (trackBytes.length >>> 8) & 255, trackBytes.length & 255, ...trackBytes];
}
function noteEvents(notes, channel, velocity = 80) {
  const events = [];
  notes.forEach(note => {
    events.push({ tick: note.start, priority: 2, bytes: [0x90 | channel, note.pitch, note.velocity || velocity] });
    events.push({ tick: note.end, priority: 1, bytes: [0x80 | channel, note.pitch, 0] });
  });
  return events;
}
function buildMidi() {
  const data = selectedHarmony(), ticksPerBeat = 480, ticksPerBar = ticksPerBeat * 4;
  const chordNotes = [], bassNotes = [], drumNotes = [];
  data.chords.forEach((chord, index) => {
    const start = index * data.bars * ticksPerBar, end = start + data.bars * ticksPerBar;
    chord.midi.forEach((pitch, noteIndex) => chordNotes.push({ pitch, start, end, velocity: noteIndex === 0 ? 74 : 63 }));
    const bassPitch = Math.max(28, chord.rootMidi - 12);
    for (let bar = 0; bar < data.bars; bar++) {
      const barStart = start + bar * ticksPerBar;
      bassNotes.push({ pitch: bassPitch, start: barStart, end: barStart + 420, velocity: 88 });
      bassNotes.push({ pitch: bassPitch, start: barStart + 960, end: barStart + 1380, velocity: 79 });
      // A soft fifth pickup near the end of each bar adds gentle movement.
      bassNotes.push({ pitch: bassPitch + 7, start: barStart + 1680, end: barStart + 1860, velocity: 55 });
      [0, 480, 960, 1440].forEach((tick, beat) => drumNotes.push({ pitch: 36, start: barStart + tick, end: barStart + tick + 90, velocity: beat === 0 ? 104 : 91 }));
      if (data.groove !== 'minimal') {
        for (let step = 0; step < 8; step++) drumNotes.push({ pitch: 42, start: barStart + step * 240, end: barStart + step * 240 + 55, velocity: step % 2 ? 42 : 55 });
      }
      if (data.groove === 'afro') {
        [720, 1680].forEach(tick => drumNotes.push({ pitch: 64, start: barStart + tick, end: barStart + tick + 100, velocity: 73 }));
        [480, 1440].forEach(tick => drumNotes.push({ pitch: 39, start: barStart + tick, end: barStart + tick + 80, velocity: 60 }));
      } else if (data.groove === 'organic') {
        [360, 840, 1320, 1800].forEach(tick => drumNotes.push({ pitch: 64, start: barStart + tick, end: barStart + tick + 95, velocity: 68 }));
        [960].forEach(tick => drumNotes.push({ pitch: 39, start: barStart + tick, end: barStart + tick + 85, velocity: 54 }));
      }
    }
  });
  const tracks = [
    makeTrack(noteEvents(chordNotes, 0), 'NASTOR - CHORDS', true, data.tempo),
    makeTrack(noteEvents(bassNotes, 1, 82), 'NASTOR - BASS', false, data.tempo),
    makeTrack(noteEvents(drumNotes, 9, 70), 'NASTOR - PERCUSSION', false, data.tempo)
  ];
  const header = [0x4d,0x54,0x68,0x64,0,0,0,6,0,1,0,3,1,0xe0];
  return new Uint8Array([...header, ...tracks.flat()]);
}
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1200);
}
$('#generate-midi').addEventListener('click', () => {
  const data = selectedHarmony(); const midi = buildMidi();
  const fileName = `nastor-${$('#key').value.toLowerCase()}-${data.tempo}bpm-afro-house.mid`;
  downloadBlob(new Blob([midi], { type: 'audio/midi' }), fileName);
  notify('3-track MIDI sketch exported.');
});

let audioContext = null;
async function previewChords() {
  const button = $('#play-preview');
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) throw new Error('Audio preview is not available in this browser.');
    audioContext = audioContext || new AudioCtx(); if (audioContext.state === 'suspended') await audioContext.resume();
    const data = selectedHarmony(), startAt = audioContext.currentTime + 0.06;
    const duration = Math.min(1.35, 60 / data.tempo * 2);
    data.chords.forEach((chord, index) => chord.midi.forEach((midiNote, noteIndex) => {
      const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
      oscillator.type = 'triangle'; oscillator.frequency.value = 440 * Math.pow(2, (midiNote - 69) / 12);
      const start = startAt + index * duration, end = start + duration * .92;
      gain.gain.setValueAtTime(0.0001, start); gain.gain.exponentialRampToValueAtTime(noteIndex === 0 ? .08 : .045, start + .05); gain.gain.exponentialRampToValueAtTime(.0001, end);
      oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(start); oscillator.stop(end + .03);
    }));
    button.textContent = '✓ Preview playing'; setTimeout(() => { button.innerHTML = '▶ Preview chords'; }, data.chords.length * duration * 1000 + 250);
  } catch (error) { notify(error.message || 'Could not start audio preview.'); }
}
$('#play-preview').addEventListener('click', previewChords);

// Bridge status is read-only for this prototype. No arbitrary desktop commands are exposed.
async function checkBridge() {
  const status = $('#bridge-status'), dot = $('.bridge-indicator'), card = $('#daw-card-status'), pill = $('#fl-page-pill');
  status.textContent = 'Checking…';
  try {
    const response = await fetch('http://127.0.0.1:4317/status', { cache: 'no-store' });
    if (!response.ok) throw new Error('The desktop helper returned an error.');
    const data = await response.json();
    dot.classList.add('online'); status.textContent = 'Bridge online'; card.textContent = 'Bridge online';
    pill.textContent = 'BRIDGE ONLINE'; pill.classList.add('online');
    $('#connect-title').textContent = 'Desktop helper detected';
    $('#connection-copy').textContent = data.message || 'The local helper is running. FL Studio itself is not yet being controlled.';
    notify('NASTOR desktop bridge detected.');
  } catch (_) {
    dot.classList.remove('online'); status.textContent = 'Bridge offline'; card.textContent = 'Offline';
    pill.textContent = 'NOT CONNECTED'; pill.classList.remove('online');
    $('#connect-title').textContent = 'Connect your production setup';
    $('#connection-copy').textContent = 'No local helper was detected. Start the included launcher on this computer, then check again.';
    notify('Desktop bridge not found.');
  }
}
$('#connect-btn').addEventListener('click', checkBridge);
$('#demo-btn').addEventListener('click', () => {
  $('#bridge-status').textContent = 'Demo preview'; $('#daw-card-status').textContent = 'Demo';
  $('#connect-title').textContent = 'Demo connection preview';
  $('#connection-copy').textContent = 'This is a visual preview only. No FL Studio connection or desktop commands are active.';
  notify('Demo preview enabled — no DAW connection made.');
});

const assistantAnswers = [
  { match: /arrange|arrangement|8.minute|eight.minute/i, text: 'ARRANGEMENT STARTER\n\n• 0:00–1:00 — DJ-friendly intro: kick, shaker and a filtered texture.\n• 1:00–2:30 — Introduce bass and the main percussion identity.\n• 2:30–3:30 — Add the melodic motif and subtle counter-rhythm.\n• 3:30–4:30 — Pull back into an atmospheric breakdown.\n• 4:30–6:30 — Main groove returns with evolving layers and fills.\n• 6:30–8:00 — Reduce elements gradually for a clean outro.\n\nKeep transitions musical and let the groove breathe.' },
  { match: /chord|harmon|minor|voic/i, text: 'HARMONIC DIRECTION\n\nTry Am9 → Fmaj7 → Cmaj7 → G6 as a starting point. Keep the upper notes close together, use a soft electric piano or muted pluck, and let a sustained pad carry the emotion. Avoid making every chord change too busy.' },
  { match: /percussion|drum|groove|122|rhythm/i, text: 'ORGANIC GROOVE\n\nStart with a steady four-on-the-floor kick. Add a rounded low conga phrase, a shaker pattern with light velocity variation, and sparse rim or wood hits. Let some percussion sit slightly behind the beat. Keep kick and bass centred; give the higher textures width.' },
  { match: /mix|master|label|release|checklist/i, text: 'MIX PREPARATION CHECKLIST\n\n1. Check phase and mono compatibility.\n2. Remove unnecessary low frequencies from non-bass elements.\n3. Balance kick and bass before adding master processing.\n4. Control harsh percussion and resonant synths.\n5. Automate transitions and breakdown energy.\n6. Leave sensible headroom for mastering.\n7. Compare at matched loudness and check on multiple playback systems.' }
];
function assistantReply(question) {
  const found = assistantAnswers.find(item => item.match.test(question));
  return found ? found.text : `PRODUCTION DIRECTION\n\nStart by defining the emotion you want the record to communicate. Choose one rhythmic anchor, one harmonic idea and one signature texture. Build a simple 8-bar loop, then make one meaningful change every 8 or 16 bars.\n\nYour question: “${question}”\n\nThis prototype currently provides offline production guidance; a live AI service has not been connected.`;
}
function askAssistant(question) {
  if (!question.trim()) return;
  $('#assistant-response').textContent = assistantReply(question.trim());
}
$$('.prompt').forEach(button => button.addEventListener('click', () => askAssistant(button.textContent)));
$('#send-prompt').addEventListener('click', () => askAssistant($('#assistant-input').value));
$('#assistant-input').addEventListener('keydown', event => { if (event.key === 'Enter') askAssistant($('#assistant-input').value); });
$('#copy-response').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('#assistant-response').textContent); notify('Production notes copied.'); }
  catch (_) { notify('Clipboard access was blocked by the browser. Select and copy the notes manually.'); }
});

updateDashboard();
