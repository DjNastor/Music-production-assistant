# NASTOR AI STUDIO — Prototype 0.3.0

A more complete production-workspace prototype for DJ Nastor and Lukulu Recordings. The sound direction is Afro House.

## What's improved

- Refreshed responsive interface with Dashboard, Production Lab, Projects, Session Planner, FL Studio Link and Studio Assistant.
- Project list and session checklist persist in the browser's local storage.
- Project backup export as JSON.
- Chord builder calculates diatonic major/minor chord qualities and supports close/open/seventh voicings.
- Browser audio preview of the chord progression.
- Multi-track Standard MIDI export: chords, bass and percussion (Afro, minimal or organic groove).
- Local desktop bridge status check, with no arbitrary command execution.
- Separate FL Studio Web launch action pointing to the official Image-Line login page; authentication stays on Image-Line.
- Double-click launchers for macOS and Windows.

## Start on Mac

1. Extract the ZIP file.
2. Keep `START_NASTOR_MAC.command` in the main `NASTOR_AI_STUDIO` folder.
3. Right-click the `.command` file and choose **Open** the first time, if macOS blocks it.
4. The launcher opens `index.html` in your default browser. When Node.js is installed, it also starts the local status bridge.

You can also run it from Terminal:

```bash
cd /path/to/NASTOR_AI_STUDIO
chmod +x START_NASTOR_MAC.command
./START_NASTOR_MAC.command
```

## Start on Windows

Extract the ZIP and double-click `START_NASTOR_WINDOWS.bat`. The dashboard opens in your default browser. The bridge starts when Node.js is installed.

## Manual bridge start

Install Node.js, then run from the project folder:

```bash
cd desktop-bridge
node server.js
```

The bridge listens only on `127.0.0.1:4317` and exposes a read-only `/status` endpoint.

## FL Studio Web mode

The FL Studio Link page includes a **Launch FL Studio Web** action that opens `https://web.image-line.com/app/login` in a separate browser tab. NASTOR does not embed the login page, read credentials, or control the logged-in Web Studio session. This is a browser shortcut/companion workflow, not a direct API integration.

Image-Line describes FL Studio Web as a browser-based, simplified product that is in beta. Image-Line says projects can be started in Web and opened in the desktop app, but project changes do not travel back from Desktop to Web. Check Image-Line's current product documentation for the latest feature and compatibility details.

## Important integration limits

This is still a browser-based prototype plus a small local status service. It does **not** directly control FL Studio, open projects in the DAW, manipulate plugins, record audio or automate mixing. The dashboard can export MIDI sketches that you can import into FL Studio manually. A real desktop controller needs its own OS-specific implementation, explicit permissions and testing with the relevant FL Studio version.

The browser app itself is designed to be lightweight, but macOS 10.13 High Sierra and Windows compatibility have not yet been tested on physical target machines. The launcher is a convenience script, not a signed installer. Node.js availability on older macOS versions must be checked separately.

## Data and backups

Projects and session tasks are stored in the current browser profile on the current computer. Use **Export project backup** regularly. Clearing browser data may remove this locally saved information.

## No live AI connection yet

The Studio Assistant uses built-in production notes. It does not currently connect to an AI API or send your music or project information anywhere.
