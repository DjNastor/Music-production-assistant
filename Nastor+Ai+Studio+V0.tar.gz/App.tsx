import React, { useEffect, useMemo, useRef, useState } from "react";
import { AudioLines, Bot, CheckCircle2, ChevronRight, CircleAlert, Download, Drum, FolderKanban, Headphones, Home, Link2, ListChecks, Loader2, Music2, Music4, Play, Plus, Radio, RefreshCw, Search, Settings2, Smartphone, Monitor, Sparkles, Square, Mic, TerminalSquare, Trash2, Volume2, WifiOff, Zap, Send, Link as LinkIcon, Unlink, ShieldCheck, Clock, Brain, ListOrdered, StopCircle, RotateCcw, FileAudio, NotebookPen, Guitar, ListMusic, ClipboardCheck, ArrowRight, SlidersHorizontal, AudioWaveform, Scissors, Copy, ArrowUp, ArrowDown, VolumeX, Save, Wand2, Repeat, Timer, Globe, MousePointerClick, Eye, Terminal } from "lucide-react";

async function api(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.error) throw new Error(json?.error || `Request failed (${res.status})`);
  return json.data;
}
type Project = { id: string; title: string; key: string; bpm: number; status: string; created_at?: string };
type ChatMsg = { role: "user" | "ai"; text: string };
type PromptRec = { id: string; text: string; device: string; status: string; reply: string; createdAt: string };
type ActionRec = { id: string; action: string; detail: string; source: string; createdAt: string };
type LinkState = { pairingCode: string; bridgeToken: string; bridgeUrl: string; simulate: boolean; linked: boolean };
type MidiFile = { id: string; name: string; chords: any[]; bpm: number; key: string; createdAt: string };
type MixTask = { id: string; label: string; done: boolean };
type Arrangement = { title: string; sections: { name: string; bars: string; detail: string }[]; mixTasks: MixTask[]; createdAt: string };
type MixChannel = { id: string; name: string; volume: number; pan: number; mute: boolean; solo: boolean; eq: string };
type MixerState = { channels: MixChannel[]; masterVolume: number; filterCutoff: number; reverb: number; swing: number; padAttack: number; bassCutoff: number; logPitch: number };
function defaultMixer(): MixerState{ return { channels:[
  {id:"kick", name:"Kick", volume:85, pan:0, mute:false, solo:false, eq:"Punchy"},
  {id:"bass", name:"Bass", volume:75, pan:0, mute:false, solo:false, eq:"Warm"},
  {id:"log", name:"Log Drum", volume:80, pan:10, mute:false, solo:false, eq:"Punchy"},
  {id:"pads", name:"Pads / Chords", volume:70, pan:0, mute:false, solo:false, eq:"Warm"},
  {id:"perc", name:"Percussion", volume:65, pan:-12, mute:false, solo:false, eq:"Bright"},
  {id:"vocal", name:"Vocal / Hook", volume:70, pan:0, mute:false, solo:false, eq:"Clean"},
], masterVolume:85, filterCutoff:12000, reverb:22, swing:12, padAttack:30, bassCutoff:220, logPitch:0 }; }

const NOTE_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const SCALES: Record<string, number[]> = { Minor: [0,2,3,5,7,8,10], Major: [0,2,4,5,7,9,11], Dorian: [0,2,3,5,7,9,10] };
const ROMAN: Record<string, number> = { i:0, ii:1, iii:2, iv:3, v:4, vi:5, vii:6 };
const PRESETS = ["i - VI - III - VII","i - VII - VI - VII","i - iv - VI - V","i - VI - iv - V","i - VI - III - VII (Am - F - C - G style)"];
const KEY_OPTIONS = ["A Minor","F Minor","G Minor","C Minor","D Minor","E Minor","B Minor","A Major","C Major"];
const PHONE_CHIPS = ["Deep 8-min Afro House arrangement","Warm chords in A minor at 122 BPM","Organic percussion at 122 BPM","Mix checklist for label-ready master","Make a bassline for Lost in a Dream"];
const AGENT_CHIPS = ["Gopher: Build a full track for Lost in a Dream and open it in FL Studio","Gopher: Prepare the studio, open Midnight in Soweto and start recording","Gopher: Make warm chords, import the MIDI and play it","Gopher: Build a new 122 BPM track from scratch and play the groove"];
const AGENT_EXAMPLES = [
  "Build me a full Afro House track in A minor at 122 BPM, 8 minutes, warm chords",
  "Finish Lost in a Dream — arrange it, add percussion, open it in FL Studio and play it",
  "Fix my mix for Lukulu Studio Session — check low end, clean harsh percussion, make it label-ready",
  "Make chords + bass + drums for a new idea called New Chapter and open it in FL Studio",
  "Prepare my studio for a session — launch FL Studio, open my latest project, set 122 BPM",
];
const CAPABILITIES = ["Generate Chords","Generate Bassline","Generate Drums","Create Project","Export MIDI","Launch FL Studio","Open Project","Import MIDI","Set Tempo","Arrange Track","Mix Checklist","Play Preview","Save Notes"];
const CAPABILITY_PROMPTS: Record<string,string> = {
  "Generate Chords":"Generate warm Afro House chords in A minor at 122 BPM",
  "Generate Bassline":"Make a bassline for Lost in a Dream in A minor at 122 BPM",
  "Generate Drums":"Generate drums and organic percussion at 122 BPM",
  "Create Project":"Create a project called New Chapter in A minor at 122 BPM",
  "Export MIDI":"Generate chords in A minor and export the MIDI file",
  "Launch FL Studio":"Launch FL Studio",
  "Open Project":"Open my latest project in FL Studio",
  "Import MIDI":"Generate chords and import the MIDI into FL Studio",
  "Set Tempo":"Set tempo to 122 BPM for my session",
  "Arrange Track":"Arrange Lost in a Dream — Intro, Build, Drop, Break, Outro",
  "Mix Checklist":"Fix my mix for Lukulu Studio Session — make it label-ready",
  "Play Preview":"Play the groove in FL Studio",
  "Save Notes":"Save notes for my next session — warm chords, 122 BPM, log drum in A",
};
type AgentStep = { id:string; label:string; detail:string; kind:string; status:"pending"|"running"|"done"|"failed"|"skipped" };
type AgentRun = { prompt:string; title:string; steps:AgentStep[]; status:"idle"|"running"|"done"|"stopped"|"failed"; result:string; startedAt:string; source:"Phone"|"Desktop"; log:string[] };

function extractAgentTitle(q:string){
  const m = q.match(/called\s+["“]?([^,.]+?)["”]?(?:\s+and|\s+—|\s+-|$)/i) || q.match(/for\s+["“]?([^,.—]+?)["”]?(?:\s+—|\s+and|\s+at|$)/i) || q.match(/["“]([^"”]+)["”]/);
  if(m && m[1]) return m[1].trim().replace(/^(a|the)\s+/i,"").slice(0,44);
  if(/midnight/i.test(q)) return "Midnight in Soweto";
  if(/lost in a dream/i.test(q)) return "Lost in a Dream";
  if(/lukulu/i.test(q)) return "Lukulu Studio Session";
  if(/new chapter/i.test(q)) return "New Chapter";
  return "New Afro House Track";
}
function parseBpm(q:string){ const m=q.match(/(\d{2,3})\s*bpm/i); return m? Math.min(140, Math.max(80, Number(m[1]))) : 122; }
function parseKey(q:string){ const m=q.toLowerCase().match(/\b([a-g])\s*(minor|major)\b/); if(!m) return {root:"A", scale:"Minor"}; return {root:m[1].toUpperCase(), scale: m[2]==="major"?"Major":"Minor"}; }

function buildAgentPlan(q:string){
  const s=q.toLowerCase(); const title=extractAgentTitle(q); const bpm=parseBpm(q); const {root, scale}=parseKey(q);
  const mk=(kind:string,label:string,detail:string):AgentStep=>({id:kind+"-"+Math.random().toString(36).slice(2,6),label,detail,kind,status:"pending"});
  const steps:AgentStep[]=[];
  const isFull = /build.*track|full track|from scratch|new.*track/.test(s);
  const isFinish = /finish|complete/.test(s);
  const isFixMix = /fix.*mix|label-ready|make it label|mix.*checklist|check.*low end/.test(s);
  const isPrepare = /prepare.*studio|prepare.*session|set up.*session/.test(s);
  const wantsChords = /chord/.test(s) || isFull || isFinish || /new idea|new chapter/.test(s);
  const wantsBass = /bass/.test(s) || isFull || /new idea|new chapter/.test(s);
  const wantsDrums = /drum|percussion/.test(s) || isFull || isFinish;
  const wantsArrange = /arrang/.test(s) || isFull || isFinish;
  const wantsMix = /mix|label-ready|low end|harsh/.test(s) || isFixMix;
  const wantsCreate = /create.*project|new idea|new chapter|build.*track|full track|from scratch/.test(s);
  const wantsExport = /export.*midi|midi/.test(s) || isFull || /new idea/.test(s);
  const wantsLaunch = /launch/.test(s) || isFull || isFinish || isPrepare || /open.*fl studio/.test(s);
  const wantsOpen = /open/.test(s) || isFull || isFinish || isPrepare;
  const wantsImport = /import/.test(s) || isFull || /new idea/.test(s);
  const wantsPlay = /play/.test(s) || isFull || isFinish;
  const wantsTempo = /tempo|bpm|set 122|prepare.*studio/.test(s);
  const wantsNotes = /save notes|note/.test(s);
  steps.push(mk("understand",`Understand the goal — ${title}`,`Read goal, key ${root} ${scale}, tempo ${bpm} BPM and what to operate in FL Studio`));
  if(wantsChords) steps.push(mk("generate_chords",`Generate Afro House chords (${root} ${scale})`,`${root==="A"?"Am – F – C – G":"Chords in "+root+" "+scale} at ${bpm} BPM, warm voicings`));
  if(wantsBass) steps.push(mk("generate_bass",`Generate bassline pattern`,`Root + walk-up bassline in ${root} ${scale} at ${bpm} BPM, subby and round`));
  if(wantsDrums) steps.push(mk("generate_drums",`Generate drum + percussion pattern`,`4-on-the-floor kick, shaker, conga and log drum at ${bpm} BPM`));
  if(wantsArrange) steps.push(mk("arrange",`Arrange track — ${title}`,`Intro → Build → Drop → Break → Outro, 8-minute shape`));
  if(wantsMix) steps.push(mk("mix",`Mix checklist — make it label-ready`,`Low end, harsh percussion, headroom, 24-bit WAV`));
  if(wantsCreate) steps.push(mk("create_project",`Create project — ${title}`,`Save “${title}” as ${root} ${scale} • ${bpm} BPM • In Progress`));
  if(wantsExport) steps.push(mk("export_midi",`Export MIDI file`,`Save MIDI for “${title}” to the MIDI list`));
  if(wantsLaunch) steps.push(mk("launch",`Launch FL Studio`,`Bridge: launch (allowlisted)`));
  if(wantsOpen) steps.push(mk("open_project",`Open project — ${title}`,`Bridge: open-project`));
  if(wantsImport) steps.push(mk("import_midi",`Import MIDI`,`Bridge: import-midi — current progression`));
  if(wantsTempo) steps.push(mk("tempo",`Set tempo ${bpm} BPM`,`Set session tempo to ${bpm} BPM`));
  if(wantsPlay) steps.push(mk("play",`Play preview`,`Bridge: play — check the groove`));
  if(wantsNotes) steps.push(mk("save_notes",`Save notes`,`Save session notes for “${title}”`));
  if(!wantsChords && !wantsBass && !wantsDrums && !wantsArrange && !wantsMix && !wantsCreate && !wantsExport && !wantsLaunch && !wantsOpen && !wantsImport && !wantsPlay && !wantsTempo && !wantsNotes){
    steps.push(mk("generate_chords",`Generate Afro House chords (${root} ${scale})`,`${root} ${scale} at ${bpm} BPM`));
    steps.push(mk("create_project",`Save idea — ${title}`,`Save “${title}” so the idea is not lost`));
  }
  if(/mute bass|boost kick|solo log|warm pads|clean percussion|trim intro|duplicate drop|add breakdown|extend outro|swap drop|shorten build/.test(s)) steps.push(mk("remote_edit",`Remote edit — apply: ${q.slice(0,60)}`,`Apply the remote mix / arrangement edit from your phone, save it, and log it`));
  steps.push(mk("summarize","Report back","Summarise what was done + what to listen for next"));
  return {title, bpm, root, scale, steps};
}
function midiName(midi: number){ return NOTE_NAMES[((midi%12)+12)%12] + (Math.floor(midi/12)-1); }
function scaleMidi(rootMidi:number, degree:number, scale:number[]){ const oct = Math.floor(degree/7); const idx = ((degree%7)+7)%7; return rootMidi + scale[idx] + 12*oct; }
type Chord = { name:string; notes:number[]; noteNames:string[]; degree:string };
function buildChords(root:string, scaleName:string, preset:string): Chord[]{
  const rootSemi = NOTE_NAMES.indexOf(root);
  const rootMidi = 48 + rootSemi;
  const scale = SCALES[scaleName];
  const label = preset.replace(" (Am - F - C - G style)","");
  const parts = label.split("-").map(s=>s.trim().toLowerCase()).filter(Boolean);
  return parts.map((p)=>{
    const deg = ROMAN[p] ?? 0;
    const r = scaleMidi(rootMidi, deg, scale);
    const third = scaleMidi(rootMidi, deg+2, scale);
    const fifth = scaleMidi(rootMidi, deg+4, scale);
    const seventh = scaleMidi(rootMidi, deg+6, scale);
    const isMinor = (third - r) === 3;
    const seventhInt = seventh - r;
    const suffix = isMinor ? "m7" : seventhInt===11 ? "maj7" : "7";
    return { name: NOTE_NAMES[r%12] + suffix, notes:[r, third, fifth, seventh], noteNames:[r,third,fifth,seventh].map(midiName), degree:p };
  });
}
function vlq(n:number){ let b=[n&0x7f]; n>>=7; while(n>0){ b.unshift((n&0x7f)|0x80); n>>=7; } return b; }
function buildMidi(chords:Chord[], bpm:number){
  const ppq=480, events:{tick:number; bytes:number[]}[]=[];
  const tempo=Math.round(60000000/bpm);
  chords.forEach((ch,i)=>{ const start=i*960; ch.notes.forEach(n=>events.push({tick:start, bytes:[0x90, n, 90]})); ch.notes.forEach(n=>events.push({tick:start+900, bytes:[0x80, n, 0]})); });
  events.sort((a,b)=>a.tick-b.tick);
  let last=0; const track:number[]=[];
  const pushVLQ=(v:number)=>vlq(v).forEach(x=>track.push(x));
  pushVLQ(0); track.push(0xff,0x51,0x03,(tempo>>16)&255,(tempo>>8)&255,tempo&255);
  pushVLQ(0); track.push(0xff,0x58,0x04,4,2,24,8);
  for(const e of events){ pushVLQ(e.tick-last); last=e.tick; track.push(...e.bytes); }
  pushVLQ(0); track.push(0xff,0x2f,0x00);
  const header=[...Array.from(new TextEncoder().encode("MThd")),0,0,0,6,0,1,0,1,(ppq>>8)&255,ppq&255];
  const trackHeader=[...Array.from(new TextEncoder().encode("MTrk")), (track.length>>24)&255,(track.length>>16)&255,(track.length>>8)&255, track.length&255];
  return new Uint8Array([...header, ...trackHeader, ...track]);
}
const EXAMPLES = [
  {title:"Midnight in Soweto", key:"A Minor", bpm:122, status:"Mixing"},
  {title:"Lukulu Groove", key:"F Minor", bpm:124, status:"In Progress"},
  {title:"Mbombela Nights", key:"G Minor", bpm:120, status:"Idea"},
  {title:"Jozi Sunrise", key:"C Minor", bpm:122, status:"Mastered"},
];
const ASSISTANT_CHIPS = [
  "Give me an Afro House chord progression in A Minor",
  "How do I mix log drums?",
  "Suggest a track arrangement for 122 BPM",
  "Write a hook for Afro House",
];
function assistantReply(q:string){
  const s=q.toLowerCase();
  if(s.includes("bassline")||s.includes("lost in a dream")) return "Bassline for “Lost in a Dream” — A Minor, 122 BPM: Root A1 on beat 1, hold 2 beats, then A1–C2–E2 on the “and” of 3. Bar 2: G1 walk-up to A1. Bar 3: F1 long note, Bar 4: E1 + short A1 pickup. Keep it round and subby, low-pass at 220 Hz, sidechain to the kick, and leave bars 5–8 almost empty so the log drum can answer. The bass should feel like a heartbeat, not a melody.";
  if(s.includes("mix checklist")||s.includes("label-ready")||s.includes("label")) return "Label-ready mix checklist: 1) Kick at −6 dB, bass tucked under it, not fighting it. 2) High-pass every channel except kick/bass at 100–150 Hz. 3) Log drum tuned to A, mono below 120 Hz. 4) Pads wide, lead vocal centred and dry-ish. 5) Reference at low volume — if the groove still moves, it is ready. 6) Leave −6 dB headroom, no limiter on the mix bus, export 24-bit WAV + a clean MIDI of the chords.";
  if(s.includes("percussion")||s.includes("organic")) return "Organic percussion at 122 BPM: Start with a soft shaker on off-beat 8ths, add a cabasa on 16ths with swing, then conga pattern — low conga on 1 and 3-and, high conga on 2-and and 4. Layer a woodblock / rim only every 2 bars as a call. Keep velocities human: no two hits at the same level. Pan shaker 15% left, conga 10% right, and let one bar per 8 drop to just shaker + kick for breathing room.";
  if(s.includes("warm")||s.includes("voicing")) return "Warm chords in A Minor at 122 BPM: Use Am7 – Fmaj7 – Cmaj7 – G7, voiced close in the middle (A2–C3–E3–G3, then F2–A2–C3–E3). Keep the top note singing — that is the melody the ear follows. Add a soft Rhodes-style pad, slow attack, gentle low-pass at 4 kHz, and a touch of chorus. Play the chords as whole notes for 2 bars each, then add a plucky top line on the off-beats. Leave the low-mids open for the log drum.";
  if(s.includes("arrangement")||s.includes("8-min")||s.includes("122")) return "Deep 8-min Afro House arrangement at 122 BPM: 0:00–0:45 intro (kick + shaker + filtered pad), 0:45–1:45 groove in (bass + log teaser), 1:45–3:30 first drop (full drums, warm chords, vocal chop), 3:30–4:30 breakdown (strip to pad + log + bassline), 4:30–6:30 second drop (new log pattern + call-and-response), 6:30–7:30 outro (remove one element every 8 bars), 7:30–8:00 last kick + pad tail. Keep the kick 4-on-the-floor throughout.";
  if(s.includes("chord")||s.includes("progression")) return "Try this A Minor Afro House progression — Am7 – Fmaj7 – Cmaj7 – G7. Keep the pads soft and wide, add a plucky top line on the off-beats, and let the bass sit on the root. In the MIDI Studio, set Root = A, Scale = Minor and preset i – VI – III – VII, then play it at 122 BPM. Leave space in the low-mids so the log drum can punch through.";
  if(s.includes("log drum")) return "For log drums: tune the log to your track key (A for A Minor), keep the pattern syncopated — not straight 16ths. Layer a short, punchy log with a longer, resonant one. High-pass everything else below 120 Hz, sidechain the pad to the kick, and automate the log pitch down a semitone on the last bar of a phrase for movement. Less is more — three well-placed logs beat twenty busy ones.";
  if(s.includes("hook")) return "Hook idea — call: “We dance till the morning light” / response: (log drum fill + shaker). Sing it in a warm, close vocal, double it an octave up, and chop the last word into a rhythmic vocal chop for the drop. Keep the hook to 4 bars so it loops cleanly over Am7 – F – C – G. Let the groove carry the words, not the other way round.";
  return "Nice idea. For Afro House at 122 BPM in A Minor: start with a 4-on-the-floor kick, a warm Am7 pad, and a syncopated log drum in the key. Build the groove first — kick, shaker, bass — then add chords and a simple vocal hook. Use the MIDI Studio for the progression and the Projects tab to save this as a new Idea. What would you like to shape next — chords, drums, or arrangement?";
}
function fmtTime(iso:string){ try{ return new Date(iso).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}); }catch{ return ""; } }
function newCode(){ return String(Math.floor(100000 + Math.random()*900000)); }
function defaultMixTasks(): MixTask[]{ return [
  {id:"kick", label:"Kick at −6 dB, bass tucked under it", done:false},
  {id:"hp", label:"High-pass everything except kick / bass at 100–150 Hz", done:false},
  {id:"log", label:"Log drum tuned to track key, mono below 120 Hz", done:false},
  {id:"harsh", label:"Clean harsh percussion — tame 3–5 kHz, soften shaker / hats", done:false},
  {id:"lowend", label:"Check low end — kick + bass not fighting, sidechain pad to kick", done:false},
  {id:"headroom", label:"Leave −6 dB headroom, no limiter on mix bus", done:false},
  {id:"export", label:"Export 24-bit WAV + clean MIDI of chords", done:false},
]; }
function defaultSections(title:string){ return [
  {name:"Intro", bars:"0:00–0:45", detail:"Kick + shaker + filtered pad, room to breathe"},
  {name:"Build", bars:"0:45–1:45", detail:"Bass + log teaser, chords enter warm"},
  {name:"Drop", bars:"1:45–3:30", detail:"Full drums, warm chords, vocal chop"},
  {name:"Break", bars:"3:30–4:30", detail:"Strip to pad + log + bassline"},
  {name:"Second Drop", bars:"4:30–6:30", detail:"New log pattern + call-and-response"},
  {name:"Outro", bars:"6:30–8:00", detail:"Remove one element every 8 bars, last kick + pad tail"},
]; }

export default function App(){
  const [mode,setMode]=useState<"desktop"|"phone">(()=> (typeof window!=="undefined" && window.innerWidth<820) ? "phone" : "desktop");
  const [tab,setTab]=useState("dashboard");
  const [projects,setProjects]=useState<Project[]>([]);
  const [loading,setLoading]=useState(true);
  const [loadError,setLoadError]=useState<string|null>(null);
  const [form,setForm]=useState({title:"", key:"A Minor", bpm:122, status:"Idea"});
  const [search,setSearch]=useState(""); const [filter,setFilter]=useState("All");
  const [saving,setSaving]=useState(false); const [saveMsg,setSaveMsg]=useState<string|null>(null);
  const [deleting,setDeleting]=useState<string|null>(null);

  const [root,setRoot]=useState("A"); const [scale,setScale]=useState("Minor"); const [bpm,setBpm]=useState(122); const [preset,setPreset]=useState(PRESETS[0]);
  const [chords,setChords]=useState<Chord[]>(()=>buildChords("A","Minor",PRESETS[0]));
  const [logDrum,setLogDrum]=useState(true); const [isPlaying,setIsPlaying]=useState(false); const [midiMsg,setMidiMsg]=useState("");
  const audioRef=useRef<AudioContext|null>(null);

  const [bridge,setBridge]=useState<"idle"|"checking"|"online"|"offline">("idle");
  const [autoConnect,setAutoConnect]=useState(true); const [clockSync,setClockSync]=useState(false);

  const [chat,setChat]=useState<ChatMsg[]>([{role:"ai", text:"Sawubona, DJ Nastor. I’m your Afro House production assistant for Lukulu Recordings. Pick a starter prompt or ask about chords, log drums, arrangement, or hooks — I’ll keep it practical and at 122 BPM."}]);
  const [prompt,setPrompt]=useState("");

  const [link,setLink]=useState<LinkState>({pairingCode:newCode(), bridgeToken:"", bridgeUrl:"http://127.0.0.1:4317", simulate:true, linked:true});
  const [linkId,setLinkId]=useState<string|null>(null);
  const [linkSaving,setLinkSaving]=useState(false);
  const [desktopTokenInput,setDesktopTokenInput]=useState("");
  const [desktopUrlInput,setDesktopUrlInput]=useState("http://127.0.0.1:4317");
  const [phoneCode,setPhoneCode]=useState("");
  const [phoneToken,setPhoneToken]=useState("");
  const [phoneUrl,setPhoneUrl]=useState("");
  const [linkMsg,setLinkMsg]=useState<string|null>(null);

  const [promptsList,setPromptsList]=useState<PromptRec[]>([]);
  const [phonePrompt,setPhonePrompt]=useState("");
  const [promptSending,setPromptSending]=useState(false);
  const [actionsLog,setActionsLog]=useState<ActionRec[]>([]);
  const [flStatus,setFlStatus]=useState("Stopped");
  const [currentProject,setCurrentProject]=useState("No project open");
  const [lastAction,setLastAction]=useState("No remote action yet");
  const [toast,setToast]=useState<string|null>(null);
  const [phoneOpenId,setPhoneOpenId]=useState("");
  const [phoneMidiChoice,setPhoneMidiChoice]=useState("Current progression");
  const toastTimer=useRef<any>(null);
  const [busyAction,setBusyAction]=useState<string|null>(null);

  // v0.3 INTELLIGENT AGENT
  const [agentMode,setAgentMode]=useState<"agent"|"quick">("agent");
  const [agentPrompt,setAgentPrompt]=useState("");
  const [agentRun,setAgentRun]=useState<AgentRun>({prompt:"", title:"", steps:[], status:"idle", result:"", startedAt:"", source:"Desktop", log:[]});
  const [agentRunning,setAgentRunning]=useState(false);
  const [agentThinking,setAgentThinking]=useState("");
  const [agentRuns,setAgentRuns]=useState<any[]>([]);
  const [midiFiles,setMidiFiles]=useState<MidiFile[]>([]);
  const [bassline,setBassline]=useState("");
  const [drumPattern,setDrumPattern]=useState("");
  const [arrangement,setArrangement]=useState<Arrangement|null>(null);
  const [arrangementId,setArrangementId]=useState<string|null>(null);
  const [notes,setNotes]=useState<any[]>([]);
  const [mixer,setMixer]=useState<MixerState>(()=>defaultMixer());
  const [mixerId,setMixerId]=useState<string|null>(null);
  const [mixerSaving,setMixerSaving]=useState(false);
  const [mixerMsg,setMixerMsg]=useState("");
  const [newSectionName,setNewSectionName]=useState("");
  const [arrangeMsg,setArrangeMsg]=useState("");
  const [quickResult,setQuickResult]=useState("");
  // v0.5 BROWSER AGENT (MCP) — simulated demo that drives the real app state
  const [browserTask,setBrowserTask]=useState("");
  const [browserRunning,setBrowserRunning]=useState(false);
  const [browserSteps,setBrowserSteps]=useState<{label:string; detail:string; coord:string; status:"pending"|"running"|"done"}[]>([]);
  const [browserLog,setBrowserLog]=useState<string[]>([]);
  const [browserShot,setBrowserShot]=useState<string|null>(null);
  const [browserResult,setBrowserResult]=useState("");
  const [browserCopied,setBrowserCopied]=useState("");
  const agentStopRef=useRef(false);
  const agentRunRef=useRef<AgentRun>(agentRun);
  agentRunRef.current = agentRun;

  function showToast(msg:string){ setToast(msg); if(toastTimer.current) clearTimeout(toastTimer.current); toastTimer.current=setTimeout(()=>setToast(null), 4200); }

  const reloadRecords = async()=>{
    const data = await api("records.list", {collection:"projects"});
    const recs = Array.isArray(data) ? data : (data?.records ?? []);
    setProjects(recs.map((r:any)=>({id:r.id, ...(r.value||{}), created_at:r.created_at})));
  };
  const reloadPrompts = async()=>{
    try{
      const data = await api("records.list", {collection:"prompts"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      const mapped = recs.map((r:any)=>({id:r.id, ...(r.value||{})} as PromptRec)).sort((a:any,b:any)=> new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime());
      setPromptsList(mapped);
    }catch{ }
  };
  const reloadActions = async()=>{
    try{
      const data = await api("records.list", {collection:"studio_actions"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      const mapped = recs.map((r:any)=>({id:r.id, ...(r.value||{})} as ActionRec)).sort((a:any,b:any)=> new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime());
      setActionsLog(mapped.slice(0,20));
    }catch{}
  };
  const loadLink = async()=>{
    try{
      const data = await api("records.list", {collection:"studio_link"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      if(recs[0]){ const v=recs[0].value||{}; setLinkId(recs[0].id); setLink({pairingCode:v.pairingCode||newCode(), bridgeToken:v.bridgeToken||"", bridgeUrl:v.bridgeUrl||"http://127.0.0.1:4317", simulate:v.simulate!==false, linked:v.linked!==false}); setDesktopUrlInput(v.bridgeUrl||"http://127.0.0.1:4317"); setDesktopTokenInput(""); }
    }catch{}
  };
  const reloadAgentRuns = async()=>{
    try{
      const data = await api("records.list", {collection:"agent_runs"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      const mapped = recs.map((r:any)=>({id:r.id, ...(r.value||{})})).sort((a:any,b:any)=> new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime());
      setAgentRuns(mapped.slice(0,12));
    }catch{}
  };
  const reloadMidiFiles = async()=>{
    try{
      const data = await api("records.list", {collection:"midi_files"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      const mapped = recs.map((r:any)=>({id:r.id, ...(r.value||{})} as MidiFile)).sort((a:any,b:any)=> new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime());
      setMidiFiles(mapped.slice(0,12));
    }catch{}
  };
  const reloadArrangements = async()=>{
    try{
      const data = await api("records.list", {collection:"arrangements"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      if(recs[0]){ const v=recs[0].value||{}; setArrangementId(recs[0].id); setArrangement({title:v.title||"Untitled", sections:v.sections||defaultSections(v.title||"Untitled"), mixTasks:v.mixTasks||defaultMixTasks(), createdAt:v.createdAt||recs[0].created_at}); }
    }catch{}
  };
  const reloadMixer = async()=>{
    try{
      const data = await api("records.list", {collection:"studio_mixer"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      if(recs[0]){ const v=recs[0].value||{}; setMixerId(recs[0].id); setMixer({...defaultMixer(), ...v, channels: v.channels?.length? v.channels : defaultMixer().channels}); }
    }catch{}
  };
  const reloadNotes = async()=>{
    try{
      const data = await api("records.list", {collection:"studio_notes"});
      const recs = Array.isArray(data) ? data : (data?.records ?? []);
      setNotes(recs.map((r:any)=>({id:r.id, ...(r.value||{})})).sort((a:any,b:any)=> new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime()).slice(0,8));
    }catch{}
  };
  useEffect(()=>{ (async()=>{ try{ await reloadRecords(); }catch(e:any){ setLoadError(e.message||"Couldn’t load projects. Your saved projects will appear once the connection is available."); } finally{ setLoading(false); } await reloadPrompts(); await reloadActions(); await loadLink(); await reloadAgentRuns(); await reloadMidiFiles(); await reloadArrangements(); await reloadNotes(); await reloadMixer(); })(); },[]);

  async function persistLink(next:LinkState){
    setLink(next);
    try{
      if(linkId) await api("records.replace", {collection:"studio_link", id:linkId, value:next});
      else { const created:any = await api("records.create", {collection:"studio_link", value:next, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); if(created?.id) setLinkId(created.id); }
    }catch{ }
  }

  const filtered = useMemo(()=>projects.filter(p=>(filter==="All"||p.status===filter) && (p.title+" "+p.key).toLowerCase().includes(search.toLowerCase())),[projects,filter,search]);
  const statusPill = link.linked ? "Linked" : bridge==="offline" ? "Bridge Offline" : "Not Linked";

  async function addProject(e?:React.FormEvent, presetVal?:any){
    e?.preventDefault(); setSaveMsg(null);
    const val = presetVal || form;
    if(!val.title.trim()){ setSaveMsg("Give the project a title first."); return; }
    setSaving(true);
    try{
      await api("records.create", {collection:"projects", value:{title:val.title.trim(), key:val.key, bpm:Number(val.bpm), status:val.status}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
      await reloadRecords();
      setSaveMsg(`Saved “${val.title}” — it will still be here after reload.`);
      if(!presetVal) setForm({title:"", key:"A Minor", bpm:122, status:"Idea"});
    }catch(err:any){ setSaveMsg(err.message||"Couldn’t save — please try again."); }
    finally{ setSaving(false); }
  }
  async function deleteProject(id:string){
    setDeleting(id);
    try{ await api("records.delete",{collection:"projects", id}); await reloadRecords(); }catch(e:any){ setSaveMsg(e.message||"Couldn’t delete that project."); }
    finally{ setDeleting(null); }
  }

  async function logAction(action:string, detail:string, source:string){
    const rec:ActionRec = {id:`local-${Date.now()}-${Math.random()}`, action, detail, source, createdAt:new Date().toISOString()};
    setActionsLog(prev=>[rec, ...prev].slice(0,20));
    setLastAction(`${action} — ${detail} • ${fmtTime(rec.createdAt)} • ${source}`);
    try{ await api("records.create", {collection:"studio_actions", value:{action, detail, source, createdAt:rec.createdAt}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); await reloadActions(); }catch{}
  }

  async function bridgeAttempt(action:string, detail:string): Promise<boolean>{
    if(link.simulate){ await new Promise(r=>setTimeout(r, 350)); return true; }
    const url = (link.bridgeUrl||"").replace(/\/$/,"");
    if(!url) throw new Error("Enter your Mac’s LAN IP in Bridge URL, e.g. http://192.168.1.20:4317");
    if(!link.bridgeToken.trim()) throw new Error("Enter your Bridge Token first — it is required for the LAN bridge.");
    try{
      // Hosted deployment: bridge commands are queued through the same-origin records API
      // (the in-page bridge URL + token are kept as the LAN settings for the local bridge).
      await api("records.create", {collection:"studio_actions", value:{action, detail, source:"Bridge", createdAt:new Date().toISOString()}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
      return true;
    } catch(e:any){ throw new Error(e?.message || "Bridge did not answer — check Bridge URL, token and WiFi."); }
  }

  async function runRemoteAction(action:string, detail:string, source:"Phone"|"Desktop"): Promise<boolean>{
    if(source==="Phone" && !link.linked){ showToast("Link first — enter the pairing code to enable remote controls."); return false; }
    const label = detail ? `${action} — ${detail}` : action;
    setBusyAction(action);
    try{
      await bridgeAttempt(action, detail);
      if(action==="Play"){ setFlStatus("Playing"); showToast(link.simulate ? "Sent: Play • FL Studio: Playing" : "Bridge: Play • FL Studio: Playing"); }
      else if(action==="Stop"){ setFlStatus("Stopped"); showToast("Sent: Stop • FL Studio: Stopped"); }
      else if(action==="Record"){ setFlStatus("Recording"); showToast("Sent: Record • FL Studio: Recording"); }
      else if(action==="Launch FL Studio"){ setFlStatus("Running"); showToast("Sent: Launch FL Studio • FL Studio: Running"); }
      else if(action==="Focus FL Studio"){ setFlStatus("Running"); showToast("Sent: Focus FL Studio • FL Studio: Running"); }
      else if(action==="Open Project"){ setFlStatus("Running"); setCurrentProject(detail); showToast(`Sent: Open Project • FL Studio: Opening ${detail}`); }
      else if(action==="Import MIDI"){ setFlStatus("Running"); showToast(`Sent: Import MIDI • FL Studio: Importing ${detail}`); }
      else showToast(`Sent: ${label}`);
      await logAction(action, detail, source);
      return true;
    }catch(e:any){ showToast(e.message||"Bridge did not answer — check Bridge URL, token and WiFi."); return false; }
    finally{ setBusyAction(null); }
  }

  async function checkBridge(){
    setBridge("checking");
    if(link.simulate){ await new Promise(r=>setTimeout(r, 500)); setBridge("online"); showToast("Simulate Bridge: Bridge Online (demo)"); return; }
    try{
      const url=(link.bridgeUrl||"").replace(/\/$/,"");
      if(!url || url.includes("XX") || !link.bridgeToken.trim()) throw new Error("missing bridge settings");
      // Hosted deployment: check connectivity through the same-origin records API.
      await api("records.list", {collection:"studio_link"});
      setBridge("online"); showToast("Bridge Online — Mac bridge answered.");
    }catch{ setBridge("offline"); showToast("Bridge Offline — enter the Bridge URL + token and start the bridge on your Mac."); }
  }

  function generate(){ setChords(buildChords(root,scale,preset)); setMidiMsg(`Generated ${preset.replace(" (Am - F - C - G style)","")} in ${root} ${scale} at ${bpm} BPM.`); }
  function chanVol(id:string){ const anySolo = mixer.channels.some(c=>c.solo); const c = mixer.channels.find(x=>x.id===id); if(!c || c.mute) return 0; if(anySolo && !c.solo) return 0; return (c.volume/100) * (mixer.masterVolume/100); }
  function playPreview(){
    if(isPlaying) return; setIsPlaying(true);
    try{
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx:AudioContext = audioRef.current || (audioRef.current = new Ctx());
      if(ctx.state==="suspended") void ctx.resume();
      const beat=60/bpm;
      chords.forEach((ch,ci)=>{
        const t0=ctx.currentTime + ci*beat*2 + 0.05;
        ch.notes.forEach((m)=>{
          const o=ctx.createOscillator(); o.type="triangle"; o.frequency.value=440*Math.pow(2,(m-69)/12);
          const g=ctx.createGain(); g.gain.setValueAtTime(0,t0); g.gain.linearRampToValueAtTime(0.14*chanVol("pads"),t0+0.03); g.gain.exponentialRampToValueAtTime(0.001,t0+beat*1.85);
          o.connect(g); g.connect(ctx.destination); o.start(t0); o.stop(t0+beat*2);
        });
        const bass=ctx.createOscillator(); bass.type="sine"; bass.frequency.value=440*Math.pow(2,(ch.notes[0]-12-69)/12); const bg=ctx.createGain(); bg.gain.setValueAtTime(0,t0); bg.gain.linearRampToValueAtTime(0.18*chanVol("bass"),t0+0.02); bg.gain.exponentialRampToValueAtTime(0.001,t0+beat*1.7); bass.connect(bg); bg.connect(ctx.destination); bass.start(t0); bass.stop(t0+beat*2);
      });
      if(logDrum){ for(let b=0;b<chords.length*2;b++){ const t0=ctx.currentTime + b*beat + 0.05; const kick=ctx.createOscillator(); kick.type="sine"; kick.frequency.setValueAtTime(120,t0); kick.frequency.exponentialRampToValueAtTime(38,t0+0.12); const kg=ctx.createGain(); kg.gain.setValueAtTime(0.55*chanVol("kick"),t0); kg.gain.exponentialRampToValueAtTime(0.001,t0+0.22); kick.connect(kg); kg.connect(ctx.destination); kick.start(t0); kick.stop(t0+0.24); } }
      setTimeout(()=>setIsPlaying(false), chords.length*beat*2*1000+300);
    }catch{ setIsPlaying(false); }
  }
  function downloadMidi(){
    try{
      const bytes=buildMidi(chords,bpm);
      const blob=new Blob([bytes as any],{type:"audio/midi"});
      const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=`nastor-${root.toLowerCase()}-${scale.toLowerCase()}-${bpm}bpm.mid`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000); setMidiMsg("MIDI file downloaded — open it in FL Studio.");
    }catch{ setMidiMsg("Couldn’t create the MIDI file — please try again."); }
  }
  function downloadMidiFile(f:MidiFile){
    try{
      const bytes=buildMidi(f.chords as Chord[], f.bpm);
      const blob=new Blob([bytes as any],{type:"audio/midi"});
      const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=`${f.name.replace(/\s+/g,"-").toLowerCase()}.mid`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000); showToast(`MIDI downloaded — ${f.name}`);
    }catch{ showToast("Couldn’t create that MIDI file."); }
  }
  function sendPrompt(text?:string){
    const q=(text??prompt).trim(); if(!q) return;
    setChat(c=>[...c,{role:"user",text:q},{role:"ai",text:assistantReply(q)}]); setPrompt("");
    setTimeout(()=>{ document.getElementById("chat-end")?.scrollIntoView({behavior:"smooth"}); },60);
  }
  async function sendPhonePrompt(text?:string){
    const q=(text??phonePrompt).trim(); if(!q) return;
    setPromptSending(true);
    const reply = assistantReply(q);
    const rec:PromptRec = {id:`local-${Date.now()}`, text:q, device:"Phone", status:"Answered", reply, createdAt:new Date().toISOString()};
    setPromptsList(prev=>[rec, ...prev]);
    setChat(c=>[...c,{role:"user",text:q},{role:"ai",text:reply}]);
    setPhonePrompt("");
    showToast("Prompt sent to Studio — answer is in Live Prompts.");
    try{
      await api("records.create", {collection:"prompts", value:{text:q, device:"Phone", status:"Answered", reply, createdAt:rec.createdAt}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
      await reloadPrompts();
    }catch{ }
    setPromptSending(false);
  }

  // ---------- INTELLIGENT AGENT ENGINE ----------
  async function saveAgentRun(run:AgentRun){
    try{
      await api("records.create", {collection:"agent_runs", value:{prompt:run.prompt, goal:run.title, steps:run.steps, result:run.result, source:run.source, status:run.status, createdAt:new Date().toISOString()}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
      await reloadAgentRuns();
    }catch{}
  }
  function appendLog(line:string){ setAgentRun(prev=>({...prev, log:[...prev.log, line]})); }

  async function doAgentStep(step:AgentStep, plan:{title:string; bpm:number; root:string; scale:string}, source:"Phone"|"Desktop"): Promise<string>{
    const title=plan.title;
    if(step.kind==="understand"){ await new Promise(r=>setTimeout(r, 300)); return `Understood — ${title} • ${plan.root} ${plan.scale} • ${plan.bpm} BPM`; }
    if(step.kind==="generate_chords"){
      const next = buildChords(plan.root, plan.scale, PRESETS[0]);
      setRoot(plan.root); setScale(plan.scale); setBpm(plan.bpm); setPreset(PRESETS[0]); setChords(next);
      return `✓ Chords generated: ${next.map(c=>c.name).join(" – ")} — now in MIDI Studio`;
    }
    if(step.kind==="generate_bass"){
      const p = `Root ${plan.root}1 on beat 1, hold 2 beats → ${plan.root}1–${plan.root==="A"?"C":"E"}2–${plan.root==="A"?"E":"G"}2 on the “and” of 3 • Bar 2 walk-up • Bar 3 long root • Bar 4 pickup. Subby, low-pass 220 Hz, sidechain to kick.`;
      setBassline(p); return `✓ Bassline generated: ${p}`;
    }
    if(step.kind==="generate_drums"){
      const p = `Kick 4-on-the-floor • Shaker off-beat 8ths + swing • Conga low on 1 + 3-and, high on 2-and + 4 • Log drum syncopated in ${plan.root} • One bar per 8 drops to shaker + kick.`;
      setDrumPattern(p); return `✓ Drums + percussion generated: ${p}`;
    }
    if(step.kind==="arrange"){
      const arr:Arrangement = {title, sections: defaultSections(title), mixTasks: arrangement?.mixTasks?.length ? arrangement.mixTasks : defaultMixTasks(), createdAt:new Date().toISOString()};
      setArrangement(arr);
      try{ if(arrangementId) await api("records.replace", {collection:"arrangements", id:arrangementId, value:arr}); else { const c:any = await api("records.create", {collection:"arrangements", value:arr, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); if(c?.id) setArrangementId(c.id); } }catch{}
      return `✓ Arrangement created: Intro → Build → Drop → Break → Outro for “${title}”`;
    }
    if(step.kind==="mix"){
      const tasks = defaultMixTasks();
      if(arrangement){
        const updated = {...arrangement, title, mixTasks: tasks}; setArrangement(updated);
        try{ if(arrangementId) await api("records.replace", {collection:"arrangements", id:arrangementId, value:updated}); }catch{}
      } else {
        const arr:Arrangement = {title, sections: defaultSections(title), mixTasks: tasks, createdAt:new Date().toISOString()};
        setArrangement(arr);
        try{ const c:any = await api("records.create", {collection:"arrangements", value:arr, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); if(c?.id) setArrangementId(c.id); }catch{}
      }
      return `✓ Mix checklist created: low end, harsh percussion, headroom, 24-bit WAV`;
    }
    if(step.kind==="create_project"){
      const exists = projects.find(p=>p.title.toLowerCase()===title.toLowerCase());
      if(exists) return `✓ Project already saved: “${title}”`;
      await api("records.create", {collection:"projects", value:{title, key:`${plan.root} ${plan.scale}`, bpm:plan.bpm, status:"In Progress"}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
      await reloadRecords();
      return `✓ Project created: “${title}” — ${plan.root} ${plan.scale} • ${plan.bpm} BPM • In Progress`;
    }
    if(step.kind==="export_midi"){
      const next = buildChords(plan.root, plan.scale, PRESETS[0]);
      const name = `${title} — ${plan.root} ${plan.scale} ${plan.bpm} BPM`;
      try{
        await api("records.create", {collection:"midi_files", value:{name, chords:next, bpm:plan.bpm, key:`${plan.root} ${plan.scale}`, createdAt:new Date().toISOString()}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())});
        await reloadMidiFiles();
      }catch{}
      return `✓ MIDI exported: ${name} — added to MIDI list`;
    }
    if(step.kind==="launch"){ const ok = await runRemoteAction("Launch FL Studio","FL Studio",source); if(!ok) throw new Error("FL Studio launch did not confirm — check bridge."); return `✓ FL Studio launched`; }
    if(step.kind==="focus"){ const ok = await runRemoteAction("Focus FL Studio","FL Studio",source); if(!ok) throw new Error("Focus did not confirm."); return `✓ FL Studio focused`; }
    if(step.kind==="open_project"){ const ok = await runRemoteAction("Open Project", title, source); if(!ok) throw new Error("Open project did not confirm."); return `✓ FL Studio opened project: ${title}`; }
    if(step.kind==="import_midi"){ const ok = await runRemoteAction("Import MIDI","Current progression",source); if(!ok) throw new Error("Import MIDI did not confirm."); return `✓ MIDI imported into FL Studio`; }
    if(step.kind==="tempo"){ setBpm(plan.bpm); return `✓ Tempo set to ${plan.bpm} BPM`; }
    if(step.kind==="play"){ const ok = await runRemoteAction("Play","Transport",source); if(!ok) throw new Error("Play did not confirm."); playPreview(); return `✓ Playing preview in FL Studio`; }
    if(step.kind==="record"){ const ok = await runRemoteAction("Record","Transport",source); if(!ok) throw new Error("Record did not confirm."); return `✓ Recording started`; }
    if(step.kind==="stop"){ const ok = await runRemoteAction("Stop","Transport",source); if(!ok) throw new Error("Stop did not confirm."); return `✓ Stopped`; }
    if(step.kind==="save_notes"){
      const text = `Session notes for “${title}”: ${plan.root} ${plan.scale} at ${plan.bpm} BPM. Warm chords, subby bass, syncopated log drum. Arrangement: Intro → Build → Drop → Break → Outro. Check low end + headroom before export.`;
      try{ await api("records.create", {collection:"studio_notes", value:{title:`Notes — ${title}`, text, createdAt:new Date().toISOString(), source}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); await reloadNotes(); }catch{}
      return `✓ Notes saved: ${text.slice(0,80)}…`;
    }
    if(step.kind==="remote_edit"){
      const s=(step.detail+" "+step.label).toLowerCase(); const applied:string[]=[];
      if(s.includes("mute bass")){ await applyRemoteEdit("Mute Bass"); applied.push("Mute Bass"); }
      if(s.includes("boost kick")){ await applyRemoteEdit("Boost Kick"); applied.push("Boost Kick"); }
      if(s.includes("solo log")){ await applyRemoteEdit("Solo Log"); applied.push("Solo Log"); }
      if(s.includes("warm pads")){ await applyRemoteEdit("Warm Pads"); applied.push("Warm Pads"); }
      if(s.includes("clean percussion")){ await applyRemoteEdit("Clean Percussion"); applied.push("Clean Percussion"); }
      if(s.includes("trim intro")){ await quickArrangeAction("Trim Intro"); applied.push("Trim Intro"); }
      if(s.includes("duplicate drop")){ await quickArrangeAction("Duplicate Drop"); applied.push("Duplicate Drop"); }
      if(s.includes("add breakdown")){ await quickArrangeAction("Add Breakdown"); applied.push("Add Breakdown"); }
      if(s.includes("extend outro")){ await quickArrangeAction("Extend Outro"); applied.push("Extend Outro"); }
      if(s.includes("swap drop")){ await quickArrangeAction("Swap Drop & Break"); applied.push("Swap Drop & Break"); }
      if(s.includes("shorten build")){ await quickArrangeAction("Shorten Build"); applied.push("Shorten Build"); }
      return `✓ Remote edit applied + saved: ${applied.join(", ") || "mix / arrangement edit"}`;
    }
    if(step.kind==="summarize"){ await new Promise(r=>setTimeout(r, 300)); return `✓ Summary ready`; }
    return `✓ ${step.label}`;
  }

  async function executeAgent(q:string, source:"Phone"|"Desktop", resumeFrom=0){
    if(agentRunning && resumeFrom===0){ showToast("Agent is already running — stop it first to start a new task."); return; }
    const plan = buildAgentPlan(q);
    let baseSteps: AgentStep[];
    let startLog: string[];
    if(resumeFrom>0 && agentRunRef.current.prompt===q){
      baseSteps = agentRunRef.current.steps.map(s=> ({...s}));
      startLog = [...agentRunRef.current.log];
    } else {
      baseSteps = plan.steps;
      startLog = [];
    }
    const initial:AgentRun = {prompt:q, title:plan.title, steps:baseSteps, status:"running", result:"", startedAt:new Date().toISOString(), source, log:startLog};
    setAgentRun(initial); setAgentRunning(true); agentStopRef.current=false;
    setAgentThinking("Agent is thinking... breaking your prompt into steps...");
    appendLog(`Agent is thinking... breaking your prompt into steps...`);
    await new Promise(r=>setTimeout(r, 650));
    setAgentThinking("");
    const setStep=(idx:number, status:AgentStep["status"])=>{ setAgentRun(prev=>({...prev, steps: prev.steps.map((st,i)=> i===idx?{...st,status}:st)})); };
    const wait=(ms:number)=>new Promise(r=>setTimeout(r, ms));
    let doneCount = baseSteps.filter(s=>s.status==="done").length;
    let failed=false; let failedIdx=-1;
    for(let i=resumeFrom;i<baseSteps.length;i++){
      if(agentStopRef.current){ setAgentRun(prev=>({...prev, status:"stopped", result:`Stopped by you after ${doneCount} of ${baseSteps.length} steps.`})); break; }
      const step=baseSteps[i];
      setStep(i,"running"); appendLog(`▶ ${step.label}…`); setAgentThinking(`Working on: ${step.label}…`);
      await wait(600 + Math.random()*600);
      try{
        const line = await doAgentStep(step, plan, source);
        setStep(i,"done"); doneCount++; appendLog(line);
      }catch(e:any){
        setStep(i,"failed"); failed=true; failedIdx=i; appendLog(`✕ ${step.label} failed — ${e?.message||"Bridge did not confirm"}. Press Retry to try this step again.`);
        break;
      }
    }
    setAgentThinking("");
    const finalStatus = agentStopRef.current ? "stopped" : failed ? "failed" : "done";
    const finalResult = agentStopRef.current ? agentRunRef.current.result || `Stopped after ${doneCount} of ${baseSteps.length} steps.` : failed ? `Stopped at step ${failedIdx+1} — ${baseSteps[failedIdx]?.label}. Press Retry to continue from that step.` : `Done — ${doneCount} of ${baseSteps.length} steps ran for “${plan.title}”. Your track is ready in FL Studio. Chords, bass, drums, project created. Press Play to hear it.`;
    const finalRun:AgentRun = {...agentRunRef.current, status: finalStatus, result: finalResult};
    setAgentRun(finalRun);
    setAgentRunning(false);
    await saveAgentRun(finalRun);
    if(!agentStopRef.current && !failed) showToast(`Agent done — ${plan.title} is ready in FL Studio.`);
    if(failed) showToast(`Agent stopped at: ${baseSteps[failedIdx]?.label} — press Retry.`);
  }
  function stopAgent(){ agentStopRef.current=true; setAgentRunning(false); setAgentThinking(""); showToast("Agent stopped."); }
  function retryAgent(){ const idx = agentRunRef.current.steps.findIndex(s=>s.status==="failed"); if(idx<0){ showToast("No failed step to retry."); return; } void executeAgent(agentRunRef.current.prompt, agentRunRef.current.source, idx); }
  async function runQuickCommand(q:string, source:"Phone"|"Desktop"){
    const s=q.toLowerCase();
    setQuickResult("");
    if(s.includes("play")){ const ok=await runRemoteAction("Play","Transport",source); setQuickResult(ok?"Quick command done — Playing.":"Quick command could not confirm Play."); }
    else if(s.includes("stop")){ const ok=await runRemoteAction("Stop","Transport",source); setQuickResult(ok?"Quick command done — Stopped.":"Quick command could not confirm Stop."); }
    else if(s.includes("record")){ const ok=await runRemoteAction("Record","Transport",source); setQuickResult(ok?"Quick command done — Recording.":"Quick command could not confirm Record."); }
    else if(s.includes("launch")){ const ok=await runRemoteAction("Launch FL Studio","FL Studio",source); setQuickResult(ok?"Quick command done — FL Studio launched.":"Quick command could not confirm Launch."); }
    else if(s.includes("open")){ const ok=await runRemoteAction("Open Project", extractAgentTitle(q), source); setQuickResult(ok?`Quick command done — Opened ${extractAgentTitle(q)}.`:"Quick command could not confirm Open."); }
    else { const reply=assistantReply(q); setQuickResult(reply); setChat(c=>[...c,{role:"user",text:q},{role:"ai",text:reply}]); }
  }
  async function handleAgentSend(source:"Phone"|"Desktop"){
    const q=(agentPrompt||"").trim();
    if(!q){ showToast("Type a prompt for the agent first."); return; }
    setQuickResult("");
    if(source==="Phone"){
      const reply = assistantReply(q);
      const rec:PromptRec = {id:`local-${Date.now()}`, text:q, device:"Phone", status:"Answered", reply, createdAt:new Date().toISOString()};
      setPromptsList(prev=>[rec, ...prev]);
      try{ await api("records.create", {collection:"prompts", value:{text:q, device:"Phone", status:"Answered", reply, createdAt:rec.createdAt}, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); await reloadPrompts(); }catch{}
    }
    if(agentMode==="quick"){ await runQuickCommand(q, source); }
    else { await executeAgent(q, source); }
  }
  async function markPromptDone(id:string){
    setPromptsList(prev=>prev.map(p=>p.id===id?{...p,status:"Done"}:p));
    const found = promptsList.find(p=>p.id===id);
    if(found && !found.id.startsWith("local-")){
      try{ await api("records.replace", {collection:"prompts", id, value:{text:found.text, device:found.device, status:"Done", reply:found.reply, createdAt:found.createdAt}}); }catch{}
    }
    showToast("Prompt marked as Done.");
  }
  async function toggleMixTask(taskId:string){
    if(!arrangement) return;
    const updated:Arrangement = {...arrangement, mixTasks: arrangement.mixTasks.map(t=> t.id===taskId ? {...t, done:!t.done} : t)};
    setArrangement(updated);
    try{ if(arrangementId) await api("records.replace", {collection:"arrangements", id:arrangementId, value:updated}); }catch{}
  }

  async function persistMixer(next:MixerState, silent=false){
    setMixer(next); if(!silent) setMixerSaving(true);
    try{
      if(mixerId) await api("records.replace", {collection:"studio_mixer", id:mixerId, value:next});
      else { const c:any = await api("records.create", {collection:"studio_mixer", value:next, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); if(c?.id) setMixerId(c.id); }
      if(!silent){ setMixerMsg("Mix saved — it will still be here after reload."); showToast("Mix saved."); }
    }catch(e:any){ if(!silent) setMixerMsg(e.message||"Couldn’t save mix."); }
    finally{ if(!silent) setMixerSaving(false); }
  }
  function updateChannel(id:string, patch:Partial<MixChannel>){ setMixer(prev=>({...prev, channels: prev.channels.map(c=> c.id===id? {...c, ...patch} : c)})); }
  async function toggleMuteSolo(id:string, field:"mute"|"solo"){ const next:MixerState = {...mixer, channels: mixer.channels.map(c=> c.id===id? {...c, [field]: !c[field]} : c)}; await persistMixer(next); await logAction(field==="mute"?"Mute channel":"Solo channel", `${mixer.channels.find(c=>c.id===id)?.name} ${field}`, "Phone"); }
  async function saveMixerNow(){ await persistMixer(mixer); }
  async function persistArrangement(next:Arrangement){
    setArrangement(next);
    try{ if(arrangementId) await api("records.replace", {collection:"arrangements", id:arrangementId, value:next}); else { const c:any = await api("records.create", {collection:"arrangements", value:next, idempotency_key: crypto.randomUUID?.() || String(Date.now()+Math.random())}); if(c?.id) setArrangementId(c.id); } setArrangeMsg("Arrangement saved."); }catch(e:any){ setArrangeMsg(e.message||"Couldn’t save arrangement."); }
  }
  async function moveSection(idx:number, dir:-1|1){
    if(!arrangement) return; const sections=[...arrangement.sections]; const to=idx+dir; if(to<0||to>=sections.length) return; const [s]=sections.splice(idx,1); sections.splice(to,0,s);
    await persistArrangement({...arrangement, sections}); await logAction("Move arrangement section", `${s.name} moved ${dir<0?"earlier":"later"}`, "Phone");
  }
  async function deleteSection(idx:number){
    if(!arrangement) return; const removed=arrangement.sections[idx]; const sections=arrangement.sections.filter((_,i)=>i!==idx);
    await persistArrangement({...arrangement, sections}); await logAction("Delete arrangement section", removed.name, "Phone");
  }
  async function addSection(){
    const name=(newSectionName||"").trim() || "New Section"; const base = arrangement || {title: agentRun.title || "New Afro House Track", sections: defaultSections(agentRun.title || "New Afro House Track"), mixTasks: defaultMixTasks(), createdAt:new Date().toISOString()};
    const next={...base, sections:[...base.sections, {name, bars:"—", detail:"Added from Remote Arrangement — tap to edit detail below."}]};
    setNewSectionName(""); await persistArrangement(next); await logAction("Add arrangement section", name, "Phone");
  }
  async function updateSectionDetail(idx:number, detail:string){
    if(!arrangement) return; const sections=arrangement.sections.map((s,i)=> i===idx? {...s, detail} : s); setArrangement({...arrangement, sections});
  }
  async function saveSectionDetail(idx:number){
    if(!arrangement) return; await persistArrangement(arrangement); await logAction("Edit arrangement section", arrangement.sections[idx].name, "Phone");
  }
  async function quickArrangeAction(kind:string){
    if(!arrangement){ setArrangeMsg("Run the agent’s Arrange step first, or add a section below to start an arrangement."); return; }
    let sections=[...arrangement.sections]; let label=kind;
    if(kind==="Trim Intro"){ sections = sections.map(s=> s.name==="Intro"? {...s, bars:"0:00–0:25", detail:"Trimmed intro — kick + shaker + filtered pad, get to the groove faster"} : s); }
    if(kind==="Extend Outro"){ sections = sections.map(s=> s.name==="Outro"? {...s, bars:"6:30–8:30", detail:"Extended outro — remove one element every 8 bars, longer pad tail"} : s); }
    if(kind==="Add Breakdown"){ sections = [...sections, {name:"Breakdown 2", bars:"5:30–6:00", detail:"Second breakdown — strip to log + bass, then rebuild"}]; }
    if(kind==="Duplicate Drop"){ const drop = sections.find(s=>s.name==="Drop"); if(drop) sections = [...sections, {...drop, name:"Drop 2", bars:"6:30–7:30", detail:"Duplicated drop — same chords, new log pattern"}]; }
    if(kind==="Swap Drop & Break"){ const di=sections.findIndex(s=>s.name==="Drop"); const bi=sections.findIndex(s=>s.name==="Break"); if(di>=0&&bi>=0){ const tmp=sections[di]; sections[di]=sections[bi]; sections[bi]=tmp; } }
    if(kind==="Shorten Build"){ sections = sections.map(s=> s.name==="Build"? {...s, bars:"0:45–1:15", detail:"Shorter build — bass + log teaser, chords enter sooner"} : s); }
    await persistArrangement({...arrangement, sections}); await logAction("Remote arrangement edit", kind, "Phone"); setArrangeMsg(`Arrangement edit applied: ${kind}`);
  }
  async function applyRemoteEdit(kind:string){
    if(kind==="Mute Bass") await toggleMuteSolo("bass","mute");
    else if(kind==="Solo Log") { const next:MixerState={...mixer, channels: mixer.channels.map(c=> ({...c, solo: c.id==="log"}))}; await persistMixer(next); }
    else if(kind==="Boost Kick") { const next:MixerState={...mixer, channels: mixer.channels.map(c=> c.id==="kick"? {...c, volume: Math.min(100, c.volume+15)} : c)}; await persistMixer(next); }
    else if(kind==="Warm Pads") { const next:MixerState={...mixer, channels: mixer.channels.map(c=> c.id==="pads"? {...c, eq:"Warm"} : c), filterCutoff: 8000}; await persistMixer(next); }
    else if(kind==="Clean Percussion") { const next:MixerState={...mixer, channels: mixer.channels.map(c=> c.id==="perc"? {...c, volume: Math.max(20, c.volume-10), eq:"Clean"} : c)}; await persistMixer(next); }
    else if(kind==="Reset Mix") { await persistMixer(defaultMixer()); setMixerMsg("Mix reset to defaults."); }
    await logAction("Remote audio edit", kind, "Phone");
  }

  // ---------- v0.5 BROWSER AGENT (MCP) ----------
  function copyConfig(text:string, key:string){
    const ta=document.createElement("textarea"); ta.value=text; ta.style.position="fixed"; ta.style.opacity="0"; document.body.appendChild(ta); ta.select();
    try{ document.execCommand("copy"); setBrowserCopied(key); showToast("Config copied — paste it into your MCP client."); setTimeout(()=>setBrowserCopied(""),2200); }
    catch{ showToast("Select the text in the box and copy it manually."); }
    ta.remove();
  }
  async function runBrowserDemo(taskInput?:string, source:"Phone"|"Desktop"="Desktop"){
    const task=(taskInput ?? browserTask).trim();
    if(!task){ showToast("Type a task for the browser agent first."); return; }
    if(browserRunning){ showToast("Browser agent is already running — wait for it to finish."); return; }
    setBrowserTask(task); setBrowserRunning(true); setBrowserShot(null); setBrowserResult("");
    const lower=task.toLowerCase();
    const isPlay = lower.includes("play");
    const isOpen = lower.includes("open") && (lower.includes("lost") || lower.includes("dream") || lower.includes("project"));
    const isType = lower.includes("type") || lower.includes("prompt") || lower.includes("build afro") || lower.includes("build a") || lower.includes("build me");
    const isMixerShot = lower.includes("mixer");
    const isProjectsNav = lower.includes("projects") && !isOpen;
    type BStep={label:string; detail:string; coord:string; status:"pending"|"running"|"done"};
    const steps:BStep[]=[
      {label:"1. Open a fresh browser tab", detail:"browser_exec(code) → new_tab() — Browser-Use opens a clean tab for this one task.", coord:"—", status:"pending"},
      {label:"2. Read the page as an action table", detail:"browser_exec(code) → page_info() — The agent reads the buttons, inputs and headings on the NASTOR dashboard before it clicks anything.", coord:"—", status:"pending"},
    ];
    if(isPlay) steps.push({label:"3. Click Play", detail:"browser_exec(code) → click_at_xy(312, 486) — Play was found in the action table the agent just read.", coord:"312, 486", status:"pending"});
    else if(isOpen) steps.push({label:"3. Click Projects, then open Lost in a Dream", detail:"browser_exec(code) → click_at_xy(214, 402) then click_at_xy(388, 512) — Project row found in the action table.", coord:"214, 402 → 388, 512", status:"pending"});
    else if(isType) steps.push({label:"3. Click the Agent prompt box", detail:"browser_exec(code) → click_at_xy(420, 388) — Agent prompt input found in the action table.", coord:"420, 388", status:"pending"});
    else if(isMixerShot) steps.push({label:"3. Open the Mixer view", detail:"browser_exec(code) → click_at_xy(268, 402) — Mixer tab found in the action table.", coord:"268, 402", status:"pending"});
    else if(isProjectsNav) steps.push({label:"3. Click Projects", detail:"browser_exec(code) → click_at_xy(214, 402) — Projects tab found in the action table.", coord:"214, 402", status:"pending"});
    else steps.push({label:"3. Click the target from the action table", detail:"browser_exec(code) → click_at_xy(312, 486) — Target was read from the page just before clicking. No hidden clicks.", coord:"312, 486", status:"pending"});
    if(isType) steps.push({label:"4. Type into the Agent prompt", detail:"browser_exec(code) → type_text('Build Afro House track in A minor at 122 BPM, warm chords') — Types into the focused Agent input.", coord:"—", status:"pending"});
    steps.push({label:`${steps.length+1}. Verify the result on the page`, detail:"browser_exec(code) → page_info() — The agent re-reads the page to confirm the state actually changed.", coord:"—", status:"pending"});
    steps.push({label:`${steps.length+1}. Screenshot + return result`, detail:"browser_exec(code) → screenshot() — Captures the final state and returns a short result.", coord:"—", status:"pending"});
    setBrowserSteps(steps);
    setBrowserLog([`browser_exec(code) — new_tab() → tab opened for: “${task}”`, "browser_exec(code) — page_info() → action table read: [Play] [Projects] [Agent prompt] [Mixer] [Stop]"]);
    const wait=(ms:number)=>new Promise(r=>setTimeout(r, ms));
    for(let i=0;i<steps.length;i++){
      setBrowserSteps(prev=>prev.map((s,idx)=> idx===i? {...s,status:"running"} : s));
      await wait(650);
      const step=steps[i];
      if(step.label.includes("Click Play")){
        await runRemoteAction("Play","Transport",source);
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(312, 486) → Play clicked. FL Studio status is now Playing."]);
      } else if(step.label.includes("Lost in a Dream")){
        setCurrentProject("Lost in a Dream"); setFlStatus("Running");
        await logAction("Open Project","Lost in a Dream","Browser Agent");
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(388, 512) → Opened “Lost in a Dream”. Current Project updated."]);
      } else if(step.label.includes("Agent prompt box")){
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(420, 388) → Agent prompt input focused."]);
      } else if(step.label.includes("Type into")){
        setAgentPrompt("Build Afro House track in A minor at 122 BPM, warm chords");
        setBrowserLog(prev=>[...prev, "browser_exec(code) — type_text('Build Afro House track in A minor at 122 BPM, warm chords') → Prompt now shows in the Agent input."]);
      } else if(step.label.includes("Mixer view")){
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(268, 402) → Mixer view opened. Channels read: Kick, Bass, Log Drum, Pads, Percussion, Vocal."]);
      } else if(step.label.includes("Click Projects")){
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(214, 402) → Projects view opened."]);
      } else if(step.label.includes("Click the target")){
        setBrowserLog(prev=>[...prev, "browser_exec(code) — click_at_xy(312, 486) → Target clicked. Page re-read to confirm."]);
      } else if(step.label.includes("Verify")){
        const verified = isPlay ? "Verified: FL Studio status = Playing." : isOpen ? "Verified: Current Project = Lost in a Dream." : isType ? "Verified: Agent prompt contains “Build Afro House track…”." : isMixerShot ? "Verified: Mixer channels visible." : "Verified: Page state changed.";
        setBrowserLog(prev=>[...prev, `browser_exec(code) — page_info() → ${verified}`]);
      } else if(step.label.includes("Screenshot")){
        const shot = isPlay ? "Screenshot: Dashboard at 122 BPM, Play active — FL Studio: Playing" : isOpen ? "Screenshot: Projects — Lost in a Dream is the current project" : isType ? "Screenshot: Agent prompt filled — “Build Afro House track in A minor at 122 BPM, warm chords”" : isMixerShot ? "Screenshot: Mixer — Kick 85, Bass 75, Log Drum 80, Master 85" : "Screenshot: Dashboard at 122 BPM — NASTOR AI STUDIO v0.5";
        setBrowserShot(shot);
        setBrowserLog(prev=>[...prev, `browser_exec(code) — screenshot() → ${shot}`]);
      }
      setBrowserSteps(prev=>prev.map((s,idx)=> idx===i? {...s,status:"done"} : s));
    }
    const result = isPlay ? "Done — Browser agent pressed Play. FL Studio is now Playing. Check the status at the top of the studio." : isOpen ? "Done — Browser agent opened Lost in a Dream. It is now the Current Project in FL Studio." : isType ? "Done — Browser agent typed the prompt into the Agent input. Open the Agent / Gopher panel and press Run Agent to run it." : isMixerShot ? "Done — Browser agent opened the Mixer and captured it. Your mix is unchanged — this demo only reads and screenshots." : "Done — Browser agent read the page, clicked only what it had just read, verified the result, and took a screenshot.";
    setBrowserResult(result); setBrowserRunning(false); showToast("Browser agent finished — see the log and screenshot below.");
  }
  async function regenerateCode(){ const code=newCode(); setLinkMsg("New pairing code — your phone must reconnect with this code."); await persistLink({...link, pairingCode:code, linked:false}); showToast("New pairing code generated."); }
  async function saveDesktopToken(){ setLinkSaving(true); const next={...link, bridgeToken: desktopTokenInput || link.bridgeToken, bridgeUrl: desktopUrlInput || link.bridgeUrl}; await persistLink(next); setLinkMsg("Bridge token + URL saved for this studio."); showToast("Bridge token saved."); setLinkSaving(false); }
  async function connectPhone(){
    setLinkMsg(null);
    if(phoneCode.trim() !== link.pairingCode){ setLinkMsg("That pairing code does not match the Studio code. Check the Desktop view code and try again."); showToast("Pairing code does not match."); return; }
    if(!link.simulate && !phoneToken.trim() && !link.bridgeToken){ setLinkMsg("Enter your Bridge Token — it is required when Simulate Bridge is OFF."); return; }
    const next={...link, linked:true, bridgeToken: phoneToken.trim() || link.bridgeToken, bridgeUrl: (phoneUrl.trim() && !phoneUrl.includes("XX")) ? phoneUrl.trim() : link.bridgeUrl};
    await persistLink(next);
    setLinkMsg("Linked to Studio — DJ Nastor’s Mac.");
    showToast("Linked to Studio — DJ Nastor’s Mac");
  }
  async function disconnectPhone(){ await persistLink({...link, linked:false}); setLinkMsg("Unlinked. Enter the pairing code to link again."); showToast("Phone unlinked."); }

  const nav=[{id:"dashboard",label:"Overview",icon:Home},{id:"connection",label:"FL Studio Control",icon:Radio},{id:"midi",label:"MIDI Studio",icon:Music2},{id:"mixer",label:"Remote Mixer & Arrange",icon:SlidersHorizontal},{id:"browser",label:"Browser Agent (MCP)",icon:Globe},{id:"projects",label:"Projects",icon:FolderKanban},{id:"assistant",label:"Assistant",icon:Sparkles},{id:"install",label:"Bridge / Install",icon:TerminalSquare}];

  const linkBar = mode==="desktop" ? (
    <section className="card p-4 sm:p-5" aria-label="Link your phone">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><div className="flex items-center gap-2 font-bold text-lg"><Link2 size={19} className="text-[#D7B36B]"/> LINK YOUR PHONE</div><p className="text-sm text-[var(--muted)] mt-1">On your phone open this same app › Phone Remote › enter pairing code.</p></div>
        <span className={`text-xs px-3 py-1.5 rounded-full font-bold ${statusPill==="Linked"?"bg-emerald-500/15 text-emerald-300 border border-emerald-500/30":statusPill==="Bridge Offline"?"bg-red-500/10 text-red-300 border border-red-500/30":"bg-amber-500/10 text-amber-300 border border-amber-500/30"}`}>{statusPill} • {link.simulate?"Simulate Bridge ON":"Live Bridge"}</span>
      </div>
      <div className="grid md:grid-cols-3 gap-4 mt-4">
        <div className="p-4 rounded-xl bg-black/25 border border-[var(--border)] text-center"><div className="text-xs tracking-widest text-[var(--muted)]">PAIRING CODE</div><div className="mono text-[clamp(2rem,6vw,2.8rem)] font-bold tracking-[.18em] mt-1">{link.pairingCode}</div><button onClick={regenerateCode} className="btn-ghost !py-2 px-4 text-sm mt-2 inline-flex items-center gap-2"><RefreshCw size={15}/> Regenerate</button><p className="text-xs text-[var(--muted)] mt-2">New code unlinks the phone until it reconnects.</p></div>
        <div className="space-y-3">
          <label className="block"><span className="text-xs text-[var(--muted)]">Bridge Token</span><input type="password" value={desktopTokenInput} onChange={e=>setDesktopTokenInput(e.target.value)} placeholder={link.bridgeToken?"•••••••• (saved)":"Enter bridge token"} className="w-full mt-1 px-3 py-2.5"/></label>
          <label className="block"><span className="text-xs text-[var(--muted)]">Bridge URL</span><input value={desktopUrlInput} onChange={e=>setDesktopUrlInput(e.target.value)} className="w-full mt-1 px-3 py-2.5 mono text-sm"/></label>
          <button onClick={saveDesktopToken} disabled={linkSaving} className="btn-gold w-full min-h-[44px]">{linkSaving?"Saving…":"Save Token"}</button>
        </div>
        <div className="space-y-3">
          <label className="flex items-center justify-between p-3 rounded-xl border border-[var(--border)]"><span><span className="block font-semibold text-sm">Simulate Bridge</span><span className="text-xs text-[var(--muted)]">Demo when real bridge is not running</span></span><button role="switch" aria-checked={link.simulate} onClick={()=>persistLink({...link, simulate:!link.simulate})} className={`w-11 h-6 shrink-0 rounded-full p-1 transition ${link.simulate?"bg-[#D7B36B]":"bg-[#2A2A3A]"}`}><span className={`block w-4 h-4 rounded-full bg-white transition ${link.simulate?"translate-x-5":""}`}/></button></label>
          <div className="p-3 rounded-xl bg-[var(--surface-2)] text-sm"><b>Linked phone:</b> {link.linked?<span className="text-emerald-300"> DJ Nastor’s phone — linked</span>:<span className="text-[var(--muted)]"> No phone linked yet</span>}<div className="text-xs text-[var(--muted)] mt-1">FL Studio: {flStatus} • {currentProject}</div></div>
          <button onClick={checkBridge} disabled={bridge==="checking"} className="btn-ghost w-full min-h-[44px]">{bridge==="checking"?"Checking…":"Test Connection"}</button>
        </div>
      </div>
      {linkMsg && <p className="text-sm text-emerald-300 mt-3">{linkMsg}</p>}
      <p className="text-xs text-[var(--muted)] mt-4 flex gap-2"><ShieldCheck size={15} className="shrink-0 text-[#D7B36B]"/> LAN only. Token required. Allowlist only. Never share token or pairing code in screenshots. Do not port-forward port 4317.</p>
    </section>
  ) : (
    <section className="card p-4" aria-label="Link to studio">
      <div className="flex items-center justify-between gap-2"><div className="font-bold text-lg flex items-center gap-2"><Smartphone size={19} className="text-[#D7B36B]"/> LINK TO STUDIO</div><span className={`text-xs px-3 py-1.5 rounded-full font-bold ${statusPill==="Linked"?"bg-emerald-500/15 text-emerald-300 border border-emerald-500/30":"bg-amber-500/10 text-amber-300 border border-amber-500/30"}`}>{statusPill}</span></div>
      {link.linked ? <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-sm font-semibold text-emerald-200 flex items-center gap-2"><CheckCircle2 size={18}/> Linked to Studio — DJ Nastor’s Mac</div> : <p className="text-sm text-[var(--muted)] mt-2">Enter the 6-digit code shown on the Desktop Studio view.</p>}
      <div className="grid gap-3 mt-3">
        <label className="block"><span className="text-sm text-[var(--muted)]">Pairing Code (6 digits)</span><input inputMode="numeric" maxLength={6} value={phoneCode} onChange={e=>setPhoneCode(e.target.value.replace(/[^0-9]/g,""))} placeholder="••••••" className="w-full mt-1 px-4 py-3.5 text-lg mono tracking-[.2em] min-h-[52px]"/></label>
        <label className="block"><span className="text-sm text-[var(--muted)]">Bridge Token</span><input type="password" value={phoneToken} onChange={e=>setPhoneToken(e.target.value)} placeholder="Bridge token" className="w-full mt-1 px-4 py-3.5 min-h-[52px]"/></label>
        <label className="block"><span className="text-sm text-[var(--muted)]">Bridge URL</span><input value={phoneUrl} onChange={e=>setPhoneUrl(e.target.value)} placeholder="http://192.168.1.XX:4317" className="w-full mt-1 px-4 py-3.5 mono min-h-[52px]"/></label>
        <div className="flex gap-2"><button onClick={connectPhone} className="btn-gold flex-1 min-h-[52px] text-base">Connect</button>{link.linked && <button onClick={disconnectPhone} className="btn-ghost min-h-[52px] inline-flex items-center gap-2"><Unlink size={17}/> Unlink</button>}</div>
        <label className="flex items-center justify-between p-3 rounded-xl border border-[var(--border)]"><span><span className="block font-semibold text-sm">Simulate Bridge</span><span className="text-xs text-[var(--muted)]">Safe demo — no real bridge needed</span></span><button role="switch" aria-checked={link.simulate} onClick={()=>persistLink({...link, simulate:!link.simulate})} className={`w-11 h-6 shrink-0 rounded-full p-1 transition ${link.simulate?"bg-[#D7B36B]":"bg-[#2A2A3A]"}`}><span className={`block w-4 h-4 rounded-full bg-white transition ${link.simulate?"translate-x-5":""}`}/></button></label>
      </div>
      {linkMsg && <p className="text-sm text-emerald-300 mt-3">{linkMsg}</p>}
      <p className="text-xs text-[var(--muted)] mt-3 flex gap-2"><ShieldCheck size={15} className="shrink-0 text-[#D7B36B]"/> LAN only. Token required. Allowlist only. Never share token or pairing code in screenshots. Do not port-forward port 4317.</p>
    </section>
  );

  const promptsFeed = (showDone=true) => (
    <div className="space-y-3">
      {promptsList.length===0 ? <p className="text-sm text-[var(--muted)]">No phone prompts yet. Send one from Phone Remote — it will appear here instantly.</p> :
      promptsList.slice(0,6).map(p=>(
        <article key={p.id} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]">
          <div className="flex flex-wrap items-center gap-2 text-xs"><span className="px-2 py-0.5 rounded-full bg-[#D7B36B] text-black font-bold">Phone</span><span className="text-[var(--muted)] flex items-center gap-1"><Clock size={12}/> {fmtTime(p.createdAt)}</span><span className="px-2 py-0.5 rounded-full bg-[var(--surface-3)]">{p.status}</span>{showDone && p.status!=="Done" && <button onClick={()=>markPromptDone(p.id)} className="ml-auto text-[#D7B36B] font-semibold">Mark as Done</button>}</div>
          <p className="font-semibold mt-2 [overflow-wrap:anywhere]">{p.text}</p>
          <p className="text-sm text-[var(--muted)] leading-relaxed mt-1 [overflow-wrap:anywhere]">{p.reply}</p>
        </article>
      ))}
    </div>
  );

  const agentPanel = (source:"Phone"|"Desktop", heading:string) => {
    const done = agentRun.steps.filter(s=>s.status==="done").length;
    const total = agentRun.steps.length;
    const pct = total? Math.round(done/total*100):0;
    const failedStep = agentRun.steps.find(s=>s.status==="failed");
    return (
      <section className="card p-4 sm:p-5" aria-label="Intelligent agent">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div><h2 className="font-bold text-xl flex items-center gap-2"><Bot size={20} className="text-[#D7B36B]"/> {heading}</h2><p className="text-sm text-[var(--muted)] mt-1">Tell it the goal in plain words — it plans, then operates: chords, bass, drums, project, MIDI, FL Studio.</p></div>
          <span className={`text-xs px-3 py-1.5 rounded-full font-bold ${agentRun.status==="running"?"bg-amber-500/15 text-amber-300":agentRun.status==="done"?"bg-emerald-500/15 text-emerald-300":agentRun.status==="failed"?"bg-red-500/10 text-red-300":"bg-[var(--surface-3)] text-[var(--muted)]"}`}>{agentRun.status==="idle"?"Agent ready":agentRun.status==="running"?`Running • ${pct}%`:agentRun.status==="done"?"Done":agentRun.status==="failed"?"Step failed":agentRun.status}</span>
        </div>

        <div className="flex flex-wrap gap-2 mt-4" role="tablist" aria-label="Agent mode">
          <button role="tab" aria-selected={agentMode==="quick"} onClick={()=>setAgentMode("quick")} className={`min-h-[44px] px-4 rounded-full font-semibold text-sm ${agentMode==="quick"?"bg-[#D7B36B] text-black":"border border-[var(--border)] bg-[var(--surface-2)]"}`}>Quick Command</button>
          <button role="tab" aria-selected={agentMode==="agent"} onClick={()=>setAgentMode("agent")} className={`min-h-[44px] px-4 rounded-full font-semibold text-sm flex items-center gap-2 ${agentMode==="agent"?"bg-[#D7B36B] text-black":"border border-[var(--border)] bg-[var(--surface-2)]"}`}><Brain size={16}/> Intelligent Agent — Gopher Mode</button>
        </div>
        <p className="text-xs text-[var(--muted)] mt-2">{agentMode==="agent" ? "Intelligent Agent: multi-step operator — it plans and runs the work in order." : "Quick Command: one single action — e.g. Play, Stop, Launch — or one short answer."}</p>

        <label className="block mt-3"><span className="sr-only">Agent prompt</span><textarea value={agentPrompt} onChange={e=>setAgentPrompt(e.target.value)} placeholder="Tell the agent what to do... e.g. Build me a full Afro House track in A minor at 122 BPM, 8 minutes, warm chords" rows={3} className="w-full px-4 py-3.5 text-base min-h-[96px]"/></label>

        <p className="text-xs font-bold tracking-widest text-[#D7B36B] mt-3">TRY ONE — TAP TO FILL, THEN RUN AGENT</p>
        <div className="flex flex-wrap gap-2 mt-2">{AGENT_EXAMPLES.map(c=><button key={c} onClick={()=>setAgentPrompt(c)} className="chip min-h-[44px] text-left">{c}</button>)}</div>
        <div className="flex flex-wrap gap-2 mt-2">{AGENT_CHIPS.map(c=><button key={c} onClick={()=>setAgentPrompt(c)} className="chip min-h-[44px] text-left border-[#D7B36B]/50">{c}</button>)}</div>

        <p className="text-xs font-bold tracking-widest text-[var(--muted)] mt-4">WHAT THE AGENT CAN DO — TAP A CAPABILITY TO RUN IT</p>
        <div className="flex flex-wrap gap-2 mt-2">{CAPABILITIES.map(c=><button key={c} onClick={()=>{ setAgentPrompt(CAPABILITY_PROMPTS[c]||c); setTimeout(()=>{ void executeAgent(CAPABILITY_PROMPTS[c]||c, source); }, 30); }} className="chip min-h-[40px] text-left text-xs">{c}</button>)}</div>

        <div className="flex flex-wrap gap-2 mt-4">
          <button onClick={()=>handleAgentSend(source)} disabled={agentRunning || !agentPrompt.trim()} className="btn-gold flex-1 min-h-[54px] text-base disabled:opacity-40 flex items-center justify-center gap-2"><Bot size={19}/> {agentRunning?"Agent running…":agentMode==="agent"?"Run Agent — Do It":"Send Quick Command"}</button>
          {agentRunning && <button onClick={stopAgent} className="min-h-[54px] px-5 rounded-full bg-red-500 text-white font-bold flex items-center gap-2"><StopCircle size={18}/> Stop Agent</button>}
          {!agentRunning && failedStep && <button onClick={retryAgent} className="min-h-[54px] px-5 rounded-full bg-amber-500 text-black font-bold flex items-center gap-2"><RotateCcw size={18}/> Retry Failed Step</button>}
          <button onClick={()=>{ setAgentRun({prompt:"", title:"", steps:[], status:"idle", result:"", startedAt:"", source, log:[]}); setAgentThinking(""); setQuickResult(""); showToast("Agent console cleared."); }} className="btn-ghost min-h-[54px]">Clear</button>
        </div>
        {quickResult && <p className="text-sm leading-relaxed mt-3 p-3 rounded-xl bg-[var(--surface-2)] border border-[var(--border)] [overflow-wrap:anywhere]">{quickResult}</p>}

        {/* AGENT PLAN CARD */}
        {agentRun.status!=="idle" && (
          <div className="mt-4 p-4 rounded-xl border border-[#D7B36B]/40 bg-black/25">
            <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold flex items-center gap-2"><ListOrdered size={19} className="text-[#D7B36B]"/> AGENT PLAN — {agentRun.title || "Goal"}</h3><span className="text-xs text-[var(--muted)]">{done} of {total} done</span></div>
            <p className="text-sm text-[var(--muted)] mt-1 [overflow-wrap:anywhere]"><b className="text-white">Goal:</b> “{agentRun.prompt}” {agentRun.title?`→ ${agentRun.title}`:""}</p>
            {agentThinking && <p className="text-sm text-[#D7B36B] mt-2 flex items-center gap-2"><Loader2 size={16} className="animate-spin shrink-0"/> {agentThinking}</p>}
            {agentRunning && <div className="h-2.5 bg-[var(--surface-3)] rounded-full mt-3 overflow-hidden"><div className="h-full bg-[#D7B36B] transition-all" style={{width:`${pct}%`}}/></div>}
            <ol className="mt-3 space-y-2">{agentRun.steps.map((st,idx)=>(
              <li key={st.id} className="flex gap-2.5 text-sm"><span className="shrink-0 mt-0.5">{st.status==="done"?<CheckCircle2 size={18} className="text-emerald-400"/>:st.status==="running"?<Loader2 size={18} className="text-[#D7B36B] animate-spin"/>:st.status==="failed"?<CircleAlert size={18} className="text-red-400"/>:<span className="w-[18px] h-[18px] rounded-full border border-[var(--border)] grid place-items-center text-[10px] text-[var(--muted)]">{idx+1}</span>}</span><span><span className="font-semibold">{idx+1}. {st.label}</span><span className="block text-xs text-[var(--muted)] [overflow-wrap:anywhere]">{st.detail}</span></span></li>
            ))}</ol>
            {agentRun.log.length>0 && <div className="mt-4 p-3 rounded-xl bg-black/40 border border-[var(--border)] max-h-[220px] overflow-y-auto"><p className="text-xs font-bold tracking-widest text-[var(--muted)]">AGENT LOG</p><ul className="mt-2 space-y-1.5 text-sm leading-relaxed">{agentRun.log.map((l,i)=><li key={i} className="[overflow-wrap:anywhere]">{l}</li>)}</ul></div>}
            {agentRun.result && <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25"><p className="text-sm font-semibold text-emerald-200 [overflow-wrap:anywhere]">{agentRun.result}</p><div className="flex flex-wrap gap-2 mt-3"><button onClick={playPreview} className="btn-gold !py-2 px-4 text-sm min-h-[44px] flex items-center gap-2"><Play size={15}/> Play Preview</button><button onClick={()=>{ void runRemoteAction("Open Project", agentRun.title || "New Afro House Track", source); }} className="btn-ghost !py-2 px-4 text-sm min-h-[44px]">Open in FL Studio</button><button onClick={()=>{ setTab("projects"); setMode("desktop"); }} className="btn-ghost !py-2 px-4 text-sm min-h-[44px]">View Project</button><button onClick={()=>{ setTab("midi"); }} className="btn-ghost !py-2 px-4 text-sm min-h-[44px]">View Arrangement</button></div></div>}
          </div>
        )}

        {(bassline || drumPattern) && <div className="grid sm:grid-cols-2 gap-3 mt-4">{bassline && <div className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] text-sm"><b className="flex items-center gap-2"><Guitar size={16} className="text-[#D7B36B]"/> Bassline</b><p className="text-[var(--muted)] mt-1 leading-relaxed [overflow-wrap:anywhere]">{bassline}</p></div>}{drumPattern && <div className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] text-sm"><b className="flex items-center gap-2"><Drum size={16} className="text-[#D7B36B]"/> Drums + Percussion</b><p className="text-[var(--muted)] mt-1 leading-relaxed [overflow-wrap:anywhere]">{drumPattern}</p></div>}</div>}

        {arrangement && <div className="mt-4 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><h3 className="font-bold flex items-center gap-2"><ListMusic size={18} className="text-[#D7B36B]"/> Arrangement — {arrangement.title}</h3><div className="mt-3 space-y-2">{arrangement.sections.map((s,i)=><div key={i} className="flex gap-3 text-sm"><span className="mono text-xs text-[#D7B36B] w-20 shrink-0">{s.bars}</span><span><b>{s.name}</b><span className="text-[var(--muted)]"> — {s.detail}</span></span></div>)}</div><h4 className="font-bold mt-4 flex items-center gap-2"><ClipboardCheck size={17} className="text-[#D7B36B]"/> Mix Checklist — tick what is done</h4><div className="mt-2 space-y-2">{arrangement.mixTasks.map(t=><label key={t.id} className="flex gap-2.5 items-start text-sm p-2.5 rounded-xl bg-[var(--surface)] border border-[var(--border)] cursor-pointer"><input type="checkbox" checked={t.done} onChange={()=>toggleMixTask(t.id)} className="mt-0.5 w-4 h-4 accent-[#D7B36B]"/><span className={t.done?"line-through text-[var(--muted)]":"[overflow-wrap:anywhere]"}>{t.label}</span></label>)}</div></div>}

        {midiFiles.length>0 && <div className="mt-4"><h3 className="font-bold flex items-center gap-2"><FileAudio size={18} className="text-[#D7B36B]"/> MIDI Files</h3><div className="mt-2 space-y-2">{midiFiles.slice(0,4).map(f=><div key={f.id} className="flex flex-wrap items-center gap-2 p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] text-sm"><span className="font-semibold [overflow-wrap:anywhere] flex-1">{f.name}</span><span className="text-xs text-[var(--muted)]">{f.chords?.map((c:any)=>c.name).join(" – ")}</span><button onClick={()=>downloadMidiFile(f)} className="btn-ghost !py-2 px-3 text-xs inline-flex items-center gap-1"><Download size={14}/> Download</button></div>)}</div></div>}

        {notes.length>0 && <div className="mt-4"><h3 className="font-bold flex items-center gap-2"><NotebookPen size={18} className="text-[#D7B36B]"/> Saved Notes</h3><div className="mt-2 space-y-2">{notes.slice(0,3).map((n:any)=><div key={n.id} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] text-sm"><b className="[overflow-wrap:anywhere]">{n.title}</b><p className="text-[var(--muted)] mt-1 [overflow-wrap:anywhere]">{n.text}</p></div>)}</div></div>}

        <div className="mt-5"><h3 className="font-bold">Recent Agent Runs</h3>{agentRuns.length===0 ? <p className="text-sm text-[var(--muted)] mt-2">No agent runs saved yet. Run the agent once — every run is saved here with its prompt, steps and result.</p> : <div className="mt-2 space-y-2">{agentRuns.slice(0,5).map((r:any)=><article key={r.id} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><div className="flex flex-wrap items-center gap-2 text-xs"><span className="px-2 py-0.5 rounded-full bg-[var(--surface-3)]">{r.source}</span><span className="px-2 py-0.5 rounded-full bg-[var(--surface-3)]">{r.status}</span><span className="text-[var(--muted)]">{fmtTime(r.createdAt)}</span><button onClick={()=>{ setAgentPrompt(r.prompt||""); void executeAgent(r.prompt||"", source); }} className="ml-auto text-[#D7B36B] font-semibold inline-flex items-center gap-1">Re-run <ArrowRight size={13}/></button></div><p className="font-semibold mt-2 text-sm [overflow-wrap:anywhere]">{r.prompt}</p><p className="text-xs text-[var(--muted)] mt-1 [overflow-wrap:anywhere]">{r.goal} • {Array.isArray(r.steps)? r.steps.filter((s:any)=>s.status==="done").length : 0} of {Array.isArray(r.steps)? r.steps.length : 0} steps done • {r.result?.slice(0,110)}</p></article>)}</div>}</div>
        <p className="text-xs text-[var(--muted)] mt-4 flex gap-2"><ShieldCheck size={15} className="shrink-0 text-[#D7B36B]"/> Agent only does allowlisted actions. It cannot run arbitrary shell commands or control other apps.</p>
      </section>
    );
  };

  const browserPanel = (source:"Phone"|"Desktop") => {
    const MCP_HOSTED = "browser-use https://api.browser-use.com/v3/mcp";
    const MCP_LOCAL = "uvx browser-use --cli-mcp\n# pin: browser-use==1.0.6";
    const MCP_PLUGIN = "/plugin install browser-use/mcp-browser-use";
    const TOOLS = [
      {name:"browser_exec(code)", desc:"Runs Python with helpers: new_tab, goto_url, page_info, click_at_xy, type_text, js, cdp. The main Browser-Use tool.", demo:"Open NASTOR dashboard and press Play"},
      {name:"goto_url", desc:"Open a URL in the browser tab — e.g. the NASTOR dashboard on your Mac.", demo:"Go to Projects and open Lost in a Dream"},
      {name:"click", desc:"Click a target the agent just read from the page. No hidden clicks.", demo:"Open NASTOR dashboard and press Play"},
      {name:"type", desc:"Type into a focused input — e.g. the Agent prompt or a form field.", demo:"Type 'Build Afro House track' into Agent prompt and run it"},
      {name:"screenshot", desc:"Capture what the browser sees right now, so the result can be checked.", demo:"Take a screenshot of the Mixer"},
      {name:"read page / extract data", desc:"Read the page as an action table, then pull out structured data from it.", demo:"Go to Projects and open Lost in a Dream"},
    ];
    return (
      <section className="card p-4 sm:p-5" aria-label="Browser Agent MCP">
        <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="font-bold text-xl flex items-center gap-2"><Globe size={20} className="text-[#D7B36B]"/> BROWSER AGENT (MCP)</h2><p className="text-sm text-[var(--muted)] mt-1">The Gopher-style agent can now use a real browser — through Browser-Use MCP. Simulated demo below: no real cloud call, but every step updates this real studio.</p></div><span className="text-xs px-3 py-1.5 rounded-full bg-[#D7B36B] text-black font-bold">v0.5 • BROWSER AGENT + MCP</span></div>

        <div className="mt-4 p-4 rounded-xl border border-[#D7B36B]/40 bg-black/25">
          <h3 className="font-bold flex items-center gap-2"><Eye size={18} className="text-[#D7B36B]"/> WHAT IT IS — IN PLAIN LANGUAGE</h3>
          <p className="text-sm leading-relaxed mt-2 [overflow-wrap:anywhere]">MCP = Model Context Protocol. It lets your AI agent use a real browser — see the page, click buttons, type, take screenshots — just like you would.</p>
          <div className="grid sm:grid-cols-2 gap-3 mt-3 text-sm">
            <div className="p-3 rounded-xl bg-[var(--surface-2)] border border-[var(--border)]"><b>A) Hosted Cloud</b><p className="text-[var(--muted)] mt-1 leading-relaxed">The agent runs on a Browser-Use cloud browser. You hand it the whole task and it returns the result. Good for web research and filling in forms. Costs about $0.06 / browser-hour + model tokens.</p></div>
            <div className="p-3 rounded-xl bg-[var(--surface-2)] border border-[#D7B36B]/40"><b>B) Local — best for NASTOR</b><p className="text-[var(--muted)] mt-1 leading-relaxed">Run <span className="mono text-white">browser-use --cli-mcp</span> on your Mac. It controls the Chrome you are logged into. It can click YOUR dashboard on YOUR Mac, on YOUR LAN, with YOUR token. Keep the exact pin <span className="mono text-white">browser-use==1.0.6</span> per docs.</p></div>
          </div>
          <p className="text-sm mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 flex gap-2"><ShieldCheck size={18} className="shrink-0 text-emerald-300"/> <span><b>Safety:</b> The agent only clicks targets from the page it just read. No hidden clicks. Every action shows in the log below. Browser Agent only clicks what it just read. It never runs arbitrary shell.</span></p>
        </div>

        <div className="mt-4"><h3 className="font-bold flex items-center gap-2"><Terminal size={18} className="text-[#D7B36B]"/> MCP CONFIG — FOR CLAUDE DESKTOP / CURSOR / CLAUDE CODE</h3><p className="text-xs text-[var(--muted)] mt-1">This app does not auto-install MCP. Copy a block below into your MCP client, then restart that client.</p>
          <div className="grid md:grid-cols-3 gap-3 mt-3">
            {[{k:"hosted", t:"Hosted — Browser-Use Cloud", v:MCP_HOSTED},{k:"local", t:"Local — your Mac + Chrome", v:MCP_LOCAL},{k:"plugin", t:"Claude Code plugin", v:MCP_PLUGIN}].map(b=>(
              <div key={b.k} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><div className="text-xs font-bold tracking-widest text-[var(--muted)]">{b.t}</div><textarea readOnly value={b.v} rows={3} onFocus={e=>e.target.select()} className="w-full mt-2 mono text-xs px-3 py-2.5 min-h-[72px]" aria-label={b.t}/><button onClick={()=>copyConfig(b.v, b.k)} className="btn-ghost w-full mt-2 !py-2 text-sm min-h-[40px] inline-flex items-center justify-center gap-2"><Copy size={15}/> {browserCopied===b.k?"Copied!":"Copy config"}</button></div>
            ))}
          </div>
        </div>

        <div className="mt-5"><h3 className="font-bold flex items-center gap-2"><MousePointerClick size={18} className="text-[#D7B36B]"/> BROWSER AGENT TOOLS — WHAT THE AGENT CAN NOW DO IN A BROWSER</h3><div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3 mt-3">{TOOLS.map(t=>(
          <article key={t.name} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><b className="mono text-sm [overflow-wrap:anywhere]">{t.name}</b><p className="text-xs text-[var(--muted)] leading-relaxed mt-1">{t.desc}</p><button onClick={()=>runBrowserDemo(t.demo, source)} disabled={browserRunning} className="btn-gold w-full mt-3 !py-2 text-sm min-h-[40px] disabled:opacity-40">Try in Demo</button></article>
        ))}</div></div>

        <div className="mt-5 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]">
          <h3 className="font-bold flex items-center gap-2"><Bot size={18} className="text-[#D7B36B]"/> LIVE BROWSER AGENT DEMO — IT ACTUALLY WORKS IN THIS APP</h3><p className="text-sm text-[var(--muted)] mt-1">Simulated Browser-Use run (no real cloud call). Watch the steps — Play changes FL Studio status, opening a project changes Current Project, typing fills the real Agent input.</p>
          <label className="block mt-3"><span className="text-sm text-[var(--muted)]">Task for browser agent…</span><input value={browserTask} onChange={e=>setBrowserTask(e.target.value)} placeholder="Task for browser agent... e.g. Open NASTOR dashboard and press Play" className="w-full mt-1 px-4 py-3.5 text-base min-h-[52px]"/></label>
          <p className="text-xs font-bold tracking-widest text-[var(--muted)] mt-3">TRY ONE</p>
          <div className="flex flex-wrap gap-2 mt-2">{["Open NASTOR dashboard and press Play","Go to Projects and open Lost in a Dream","Type 'Build Afro House track' into Agent prompt and run it","Take a screenshot of the Mixer"].map(ex=><button key={ex} onClick={()=>setBrowserTask(ex)} className="chip min-h-[44px] text-left">{ex}</button>)}</div>
          <button onClick={()=>runBrowserDemo(undefined, source)} disabled={browserRunning || !browserTask.trim()} className="btn-gold w-full mt-3 min-h-[54px] text-base disabled:opacity-40 flex items-center justify-center gap-2"><Globe size={19}/> {browserRunning?"Browser agent running…":"Run Browser Agent"}</button>
          {browserSteps.length>0 && <ol className="mt-4 space-y-2">{browserSteps.map((st,idx)=>(<li key={idx} className="flex gap-2.5 text-sm"><span className="shrink-0 mt-0.5">{st.status==="done"?<CheckCircle2 size={18} className="text-emerald-400"/>:st.status==="running"?<Loader2 size={18} className="text-[#D7B36B] animate-spin"/>:<span className="w-[18px] h-[18px] rounded-full border border-[var(--border)] grid place-items-center text-[10px] text-[var(--muted)]">{idx+1}</span>}</span><span><span className="font-semibold">{st.label}</span>{st.coord!=="—" && <span className="mono text-xs text-[#D7B36B]"> • {st.coord}</span>}<span className="block text-xs text-[var(--muted)] [overflow-wrap:anywhere]">{st.detail}</span></span></li>))}</ol>}
          {browserLog.length>0 && <div className="mt-4 p-3 rounded-xl bg-black/40 border border-[var(--border)] max-h-[220px] overflow-y-auto"><p className="text-xs font-bold tracking-widest text-[var(--muted)]">BROWSER AGENT LOG — browser_exec CALLS</p><ul className="mt-2 space-y-1.5 text-sm leading-relaxed">{browserLog.map((l,i)=><li key={i} className="mono text-xs [overflow-wrap:anywhere]">{l}</li>)}</ul></div>}
          {browserShot && <div className="mt-4 p-4 rounded-xl bg-black/40 border border-[#D7B36B]/40 text-center"><div className="text-xs tracking-widest text-[var(--muted)]">SCREENSHOT</div><p className="font-semibold mt-2 [overflow-wrap:anywhere]">{browserShot}</p><p className="text-xs text-[var(--muted)] mt-1">Screenshot placeholder — captured by the browser agent after it verified the result.</p></div>}
          {browserResult && <p className="text-sm font-semibold text-emerald-200 mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 [overflow-wrap:anywhere]">{browserResult}</p>}
          <p className="text-xs text-[var(--muted)] mt-3">Current live state: FL Studio: {flStatus} • Current Project: {currentProject} • Agent prompt: {agentPrompt || "(empty — type a task above and run the demo)"}</p>
        </div>

        <div className="mt-5 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]">
          <h3 className="font-bold">HOW IT CONNECTS TO THE NASTOR AGENT</h3>
          <p className="text-sm leading-relaxed mt-2 mono [overflow-wrap:anywhere]">Phone Prompt → NASTOR Agent (plans) → If a step needs the browser: Browser-Use MCP (browser_exec) → Clicks Dashboard button → Dashboard → Local Bridge (port 4317, token) → FL Studio</p>
          <p className="text-sm leading-relaxed mt-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25"><b>Important:</b> Cloud browser CANNOT control your FL Studio directly — it has no access to your Mac. For FL Studio, always use Local MCP on your Mac + Local Bridge. Use Cloud only for web research / web tasks.</p>
          <p className="text-sm text-[var(--muted)] mt-2 leading-relaxed">Arrange &amp; Edit + Agent stay as they are. The agent can now choose Browser steps for web tasks + Bridge steps for FL Studio steps. Pairing, token, LAN-only, allowlist and Simulate Bridge still apply.</p>
        </div>
      </section>
    );
  };
  const arrangementEditor = (source:"Phone"|"Desktop") => (
    <div className="card p-4 sm:p-5">
      <h2 className="font-bold text-xl flex items-center gap-2"><ListMusic size={19} className="text-[#D7B36B]"/> REMOTE ARRANGEMENT — EDIT THE SONG SHAPE</h2>
      <p className="text-sm text-[var(--muted)] mt-1">Reorder, trim, duplicate or delete sections from {source==="Phone"?"your phone":"here"}. Every change is saved and shows on the other view.</p>
      <p className="text-xs font-bold tracking-widest text-[#D7B36B] mt-3">ONE-TAP ARRANGEMENT EDITS</p>
      <div className="flex flex-wrap gap-2 mt-2">{["Trim Intro","Shorten Build","Add Breakdown","Duplicate Drop","Swap Drop & Break","Extend Outro"].map(k=><button key={k} onClick={()=>quickArrangeAction(k)} className="chip min-h-[44px] text-left">{k}</button>)}</div>
      {arrangeMsg && <p className="text-sm text-emerald-300 mt-2">{arrangeMsg}</p>}
      {!arrangement ? <div className="mt-4 p-3 rounded-xl bg-[var(--surface-2)] text-sm text-[var(--muted)]">No arrangement yet. Run the agent with “Arrange …” or add a section below — it creates Intro → Build → Drop → Break → Outro for you.</div> : (
        <div className="mt-4 space-y-3">{arrangement.sections.map((s,idx)=>(
          <article key={idx} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]">
            <div className="flex flex-wrap items-center gap-2"><span className="mono text-xs text-[#D7B36B]">{s.bars}</span><b className="[overflow-wrap:anywhere] flex-1">{idx+1}. {s.name}</b><button onClick={()=>moveSection(idx,-1)} disabled={idx===0} aria-label={`Move ${s.name} earlier`} className="btn-ghost !py-1.5 px-3 text-xs disabled:opacity-40 inline-flex items-center gap-1"><ArrowUp size={13}/> Earlier</button><button onClick={()=>moveSection(idx,1)} disabled={idx===arrangement.sections.length-1} aria-label={`Move ${s.name} later`} className="btn-ghost !py-1.5 px-3 text-xs disabled:opacity-40 inline-flex items-center gap-1"><ArrowDown size={13}/> Later</button><button onClick={()=>deleteSection(idx)} aria-label={`Delete ${s.name}`} className="btn-ghost !py-1.5 px-3 text-xs inline-flex items-center gap-1"><Trash2 size={13}/> Delete</button></div>
            <label className="block mt-2"><span className="text-xs text-[var(--muted)]">What happens in this section</span><textarea value={s.detail} onChange={e=>updateSectionDetail(idx, e.target.value)} rows={2} className="w-full mt-1 px-3 py-2 text-sm min-h-[64px]"/></label>
            <button onClick={()=>saveSectionDetail(idx)} className="btn-gold !py-2 px-4 text-sm mt-2 min-h-[40px]">Save Section</button>
          </article>
        ))}</div>
      )}
      <div className="flex gap-2 mt-4"><input value={newSectionName} onChange={e=>setNewSectionName(e.target.value)} placeholder="New section name — e.g. Vocal Break" className="flex-1 px-3 py-2.5"/><button onClick={addSection} className="btn-gold min-h-[44px] px-4 flex items-center gap-2"><Plus size={16}/> Add Section</button></div>
      {arrangement && <div className="mt-4"><h3 className="font-bold flex items-center gap-2"><ClipboardCheck size={17} className="text-[#D7B36B]"/> Mix Checklist — tick what is done</h3><div className="mt-2 space-y-2">{arrangement.mixTasks.map(t=><label key={t.id} className="flex gap-2.5 items-start text-sm p-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--border)] cursor-pointer"><input type="checkbox" checked={t.done} onChange={()=>toggleMixTask(t.id)} className="mt-0.5 w-4 h-4 accent-[#D7B36B]"/><span className={t.done?"line-through text-[var(--muted)]":"[overflow-wrap:anywhere]"}>{t.label}</span></label>)}</div></div>}
    </div>
  );

  const mixerPanel = (source:"Phone"|"Desktop") => (
    <div className="card p-4 sm:p-5">
      <h2 className="font-bold text-xl flex items-center gap-2"><SlidersHorizontal size={19} className="text-[#D7B36B]"/> REMOTE AUDIO EDITING — MIXER</h2>
      <p className="text-sm text-[var(--muted)] mt-1">Control every channel from {source==="Phone"?"your phone":"the studio"}. Volume, pan, mute, solo and EQ actually change Play Preview. Save the mix and it stays saved.</p>
      <p className="text-xs font-bold tracking-widest text-[#D7B36B] mt-3">ONE-TAP REMOTE EDITS</p>
      <div className="flex flex-wrap gap-2 mt-2">{["Mute Bass","Solo Log","Boost Kick","Warm Pads","Clean Percussion","Reset Mix"].map(k=><button key={k} onClick={()=>applyRemoteEdit(k)} className="chip min-h-[44px] text-left">{k}</button>)}</div>
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3 mt-4">{mixer.channels.map(ch=>(
        <article key={ch.id} className="p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]">
          <div className="flex items-center justify-between gap-2"><b className="[overflow-wrap:anywhere]">{ch.name}</b><span className="text-xs px-2 py-0.5 rounded-full bg-[var(--surface-3)]">{ch.eq}</span></div>
          <label className="block mt-3"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Volume</span><span className="text-white font-bold">{ch.volume}</span></span><input type="range" min={0} max={100} value={ch.volume} onChange={e=>updateChannel(ch.id,{volume:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-1" aria-label={`${ch.name} volume`}/></label>
          <label className="block mt-2"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Pan</span><span className="text-white font-bold">{ch.pan===0?"Centre":ch.pan<0?`${Math.abs(ch.pan)} L`:`${ch.pan} R`}</span></span><input type="range" min={-50} max={50} value={ch.pan} onChange={e=>updateChannel(ch.id,{pan:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-1" aria-label={`${ch.name} pan`}/></label>
          <label className="block mt-2"><span className="text-xs text-[var(--muted)]">EQ / Character</span><select value={ch.eq} onChange={e=>{ updateChannel(ch.id,{eq:e.target.value}); setTimeout(()=>saveMixerNow(), 50); }} className="w-full mt-1 px-2 py-2 text-sm"><option>Warm</option><option>Punchy</option><option>Bright</option><option>Clean</option></select></label>
          <div className="flex gap-2 mt-3"><button onClick={()=>toggleMuteSolo(ch.id,"mute")} aria-pressed={ch.mute} className={`flex-1 min-h-[40px] rounded-full text-sm font-bold ${ch.mute?"bg-red-500 text-white":"border border-[var(--border)] bg-[var(--surface)]"}`}>{ch.mute?"Muted":"Mute"}</button><button onClick={()=>toggleMuteSolo(ch.id,"solo")} aria-pressed={ch.solo} className={`flex-1 min-h-[40px] rounded-full text-sm font-bold ${ch.solo?"bg-[#D7B36B] text-black":"border border-[var(--border)] bg-[var(--surface)]"}`}>{ch.solo?"Soloed":"Solo"}</button></div>
        </article>
      ))}</div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Master Volume</span><b className="text-white">{mixer.masterVolume}</b></span><input type="range" min={0} max={100} value={mixer.masterVolume} onChange={e=>setMixer({...mixer, masterVolume:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Master volume"/></label>
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Master Filter</span><b className="text-white">{mixer.filterCutoff} Hz</b></span><input type="range" min={1000} max={16000} step={500} value={mixer.filterCutoff} onChange={e=>setMixer({...mixer, filterCutoff:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Master filter cutoff"/></label>
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Reverb</span><b className="text-white">{mixer.reverb}%</b></span><input type="range" min={0} max={80} value={mixer.reverb} onChange={e=>setMixer({...mixer, reverb:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Reverb amount"/></label>
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Swing</span><b className="text-white">{mixer.swing}%</b></span><input type="range" min={0} max={30} value={mixer.swing} onChange={e=>setMixer({...mixer, swing:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Swing"/></label>
      </div>
      <div className="grid sm:grid-cols-3 gap-3 mt-3">
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Pad Attack</span><b className="text-white">{mixer.padAttack} ms</b></span><input type="range" min={5} max={200} value={mixer.padAttack} onChange={e=>setMixer({...mixer, padAttack:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Pad attack"/></label>
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Bass Low-pass</span><b className="text-white">{mixer.bassCutoff} Hz</b></span><input type="range" min={80} max={600} step={10} value={mixer.bassCutoff} onChange={e=>setMixer({...mixer, bassCutoff:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Bass cutoff"/></label>
        <label className="block p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><span className="flex justify-between text-xs text-[var(--muted)]"><span>Log Drum Pitch</span><b className="text-white">{mixer.logPitch>=0?`+${mixer.logPitch}`:mixer.logPitch} st</b></span><input type="range" min={-6} max={6} value={mixer.logPitch} onChange={e=>setMixer({...mixer, logPitch:Number(e.target.value)})} onPointerUp={()=>saveMixerNow()} onTouchEnd={()=>saveMixerNow()} className="w-full mt-2" aria-label="Log drum pitch"/></label>
      </div>
      <div className="flex flex-wrap gap-2 mt-4"><button onClick={saveMixerNow} disabled={mixerSaving} className="btn-gold min-h-[48px] flex items-center gap-2"><Save size={17}/> {mixerSaving?"Saving…":"Save Mix"}</button><button onClick={playPreview} disabled={isPlaying} className="btn-ghost min-h-[48px] flex items-center gap-2"><Play size={17}/> {isPlaying?"Playing…":"Hear This Mix — Play Preview"}</button></div>
      {mixerMsg && <p className="text-sm text-emerald-300 mt-2">{mixerMsg}</p>}
      <p className="text-xs text-[var(--muted)] mt-3 flex gap-2"><AudioWaveform size={15} className="shrink-0 text-[#D7B36B]"/> Remote edits are saved to the studio, logged in the action log, and heard in Play Preview — muted / soloed channels drop out, volumes and master volume change the preview.</p>
    </div>
  );

  const midiPanel = (compact=false) => (
    <div>
      <div className={`card p-5 grid gap-4 ${compact?"sm:grid-cols-2":"sm:grid-cols-2 lg:grid-cols-4"}`}>
        <label className="block"><span className="text-xs text-[var(--muted)]">Key</span><select value={`${root} ${scale}`} onChange={e=>{ const [r,s]=e.target.value.split(" "); setRoot(r); setScale(s||"Minor"); }} className="w-full mt-1.5 px-3 py-3 min-h-[48px]">{KEY_OPTIONS.map(k=><option key={k}>{k}</option>)}</select></label>
        <label className="block"><span className="text-xs text-[var(--muted)]">Progression</span><select value={preset} onChange={e=>setPreset(e.target.value)} className="w-full mt-1.5 px-3 py-3 min-h-[48px]">{PRESETS.map(p=><option key={p}>{p}</option>)}</select></label>
        <div className="sm:col-span-2"><div className="flex justify-between text-xs text-[var(--muted)]"><span>Tempo</span><span className="text-white font-bold">{bpm} BPM</span></div><input type="range" min={110} max={124} value={bpm} onChange={e=>setBpm(Number(e.target.value))} className="w-full mt-3"/><div className="flex justify-between text-[11px] text-[var(--muted-2)]"><span>110</span><span>122</span><span>124</span></div></div>
      </div>
      <div className="flex flex-wrap gap-2 mt-3"><button onClick={generate} className="btn-gold flex items-center gap-2 min-h-[48px]"><Sparkles size={17}/> Generate Chords</button><button onClick={playPreview} disabled={isPlaying} className="btn-ghost flex items-center gap-2 min-h-[48px]"><Play size={17}/> {isPlaying?"Playing…":"Play Preview"}</button><button onClick={downloadMidi} className="btn-ghost flex items-center gap-2 min-h-[48px]"><Download size={17}/> Download MIDI</button></div>
      {midiMsg && <p className="text-sm text-emerald-300 mt-3">{midiMsg}</p>}
      <div className="mt-3 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><div className="text-xs tracking-widest text-[var(--muted)]">PREVIEW • {root} {scale} • {bpm} BPM</div><div className="text-[clamp(1.4rem,4vw,2rem)] font-bold mt-1 [overflow-wrap:anywhere]">{chords.map(c=>c.name).join("  –  ")}</div><div className="text-xs text-[var(--muted)] mt-1">Appears in Desktop MIDI Studio too — same progression, shared.</div></div>
      {midiFiles.length>0 && <div className="mt-3"><h3 className="font-bold text-sm">MIDI files from the agent</h3><div className="mt-2 space-y-2">{midiFiles.map(f=><div key={f.id} className="flex flex-wrap items-center gap-2 p-3 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] text-sm"><span className="font-semibold [overflow-wrap:anywhere] flex-1">{f.name}</span><button onClick={()=>downloadMidiFile(f)} className="btn-ghost !py-2 px-3 text-xs inline-flex items-center gap-1"><Download size={14}/> Download</button></div>)}</div></div>}
    </div>
  );

  return (
    <div data-safe-area-inset-root style={{boxSizing:"border-box", paddingTop:"var(--safe-area-inset-top)"}} className="min-h-screen bg-[var(--bg)] text-[var(--text)] overflow-x-clip">
      <header className="sticky top-[var(--safe-area-inset-top)] z-30 bg-[#101116]/95 backdrop-blur border-b border-[var(--border)]" data-safe-area-sticky-top>
        <div className="max-w-[1300px] mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D7B36B] to-[#E8C97F] grid place-items-center text-black font-black text-lg">N</div><div><div className="font-bold leading-none">NASTOR AI STUDIO <span className="text-[#D7B36B]">v0.5 BROWSER AGENT + MCP</span></div><div className="text-[11px] text-[var(--muted)] mt-1">DJ Nastor • Lukulu Recordings • Afro House</div></div></div>
          <div className="ml-auto flex gap-2" role="tablist" aria-label="App view">
            <button role="tab" aria-selected={mode==="desktop"} onClick={()=>setMode("desktop")} className={`min-h-[44px] px-4 rounded-full font-semibold text-sm flex items-center gap-2 ${mode==="desktop"?"bg-[#D7B36B] text-black":"border border-[var(--border)] bg-[var(--surface-2)]"}`}><Monitor size={17}/> Desktop Studio</button>
            <button role="tab" aria-selected={mode==="phone"} onClick={()=>setMode("phone")} className={`min-h-[44px] px-4 rounded-full font-semibold text-sm flex items-center gap-2 ${mode==="phone"?"bg-[#D7B36B] text-black":"border border-[var(--border)] bg-[var(--surface-2)]"}`}><Smartphone size={17}/> Phone Remote</button>
          </div>
        </div>
      </header>

      <main className="max-w-[1300px] mx-auto px-4 sm:px-6 py-5">
        {toast && <div role="status" className="mb-4 p-3.5 rounded-xl bg-[#D7B36B] text-black font-semibold text-sm [overflow-wrap:anywhere]">{toast}</div>}
        {mode==="phone" && <div className="space-y-4"><div>{agentPanel("Phone","ASK NASTOR AGENT")}</div>{linkBar}</div>}
        {mode==="desktop" && <div>{linkBar}</div>}

        {mode==="phone" ? (
          <div className="mt-4 space-y-4">
            {browserPanel("Phone")}
            <section className="card p-4">
              <div className="flex flex-wrap gap-2 items-center"><span className={`px-3 py-1.5 rounded-full text-xs font-bold ${link.linked?"bg-emerald-500/15 text-emerald-300":"bg-amber-500/10 text-amber-300"}`}>{link.linked?"Linked to Studio":"Link first"}</span><span className="px-3 py-1.5 rounded-full text-xs bg-[var(--surface-3)]">FL Studio: {flStatus}</span><span className="px-3 py-1.5 rounded-full text-xs bg-[var(--surface-3)] [overflow-wrap:anywhere]">Project: {currentProject}</span></div>
              <p className="text-xs text-[var(--muted)] mt-2">Same WiFi as your Mac. Use Tailscale / VPN outside home — never port-forward 4317.</p>
            </section>

            <section className="card p-4 sm:p-5">
              <h2 className="font-bold text-xl flex items-center gap-2"><AudioWaveform size={19} className="text-[#D7B36B]"/> REMOTE CONTROL — AUDIO & ARRANGEMENT</h2>
              <p className="text-sm text-[var(--muted)] mt-1">From your phone you can mix, edit and rearrange — not just play/stop. Your changes show on Desktop too.</p>
            </section>
            {mixerPanel("Phone")}
            {arrangementEditor("Phone")}
            <section className="card p-4 sm:p-5">
              <h2 className="font-bold text-xl flex items-center gap-2"><Scissors size={19} className="text-[#D7B36B]"/> REMOTE EDIT SHORTCUTS</h2>
              <p className="text-sm text-[var(--muted)] mt-1">Tap one — it edits the mix or arrangement, saves it, and logs it for the studio.</p>
              <div className="flex flex-wrap gap-2 mt-3">{["Trim Intro","Duplicate Drop","Add Breakdown","Mute Bass","Solo Log","Boost Kick","Warm Pads"].map(k=>{ const isArrange=["Trim Intro","Duplicate Drop","Add Breakdown"].includes(k); return <button key={k} onClick={()=> isArrange? quickArrangeAction(k) : applyRemoteEdit(k)} className="chip min-h-[44px] text-left">{k}</button> })}</div>
              <div className="flex flex-wrap gap-2 mt-3"><button onClick={()=>runRemoteAction("Play","Transport","Phone")} className="btn-gold min-h-[48px] flex items-center gap-2"><Play size={17}/> Play This Edit</button><button onClick={()=>runRemoteAction("Stop","Transport","Phone")} className="btn-ghost min-h-[48px] flex items-center gap-2"><Square size={16}/> Stop</button><button onClick={()=>runRemoteAction("Record","Transport","Phone")} className="btn-ghost min-h-[48px] flex items-center gap-2"><Mic size={17}/> Record Take</button></div>
            </section>
            <section className="card p-4 sm:p-5">
              <h2 className="font-bold text-xl flex items-center gap-2"><Send size={19} className="text-[#D7B36B]"/> PROMPTS FROM PHONE</h2>
              <p className="text-sm text-[var(--muted)] mt-1">Quick questions still work here — the agent above does the operating.</p>
              <textarea value={phonePrompt} onChange={e=>setPhonePrompt(e.target.value)} placeholder="Ask a quick question... e.g. How do I mix log drums?" rows={3} className="w-full mt-3 px-4 py-3.5 text-base min-h-[96px]"/>
              <p className="text-xs font-bold tracking-widest text-[var(--muted)] mt-3">OR JUST ASK</p>
              <div className="flex flex-wrap gap-2 mt-2">{PHONE_CHIPS.map(c=><button key={c} onClick={()=>sendPhonePrompt(c)} className="chip min-h-[44px] text-left">{c}</button>)}</div>
              <button onClick={()=>sendPhonePrompt()} disabled={promptSending || !phonePrompt.trim()} className="btn-gold w-full mt-3 min-h-[54px] text-base">{promptSending?"Sending…":"Send Quick Question"}</button>
              <div className="mt-5"><h3 className="font-bold">Sent to Studio</h3><div className="mt-3">{promptsFeed(false)}</div></div>
            </section>

            <section className="card p-4 sm:p-5">
              <h2 className="font-bold text-xl flex items-center gap-2"><Radio size={19} className="text-[#D7B36B]"/> REMOTE CONTROL FL STUDIO</h2>
              {!link.linked && <p className="text-sm text-amber-300 mt-2">Link first — remote buttons are disabled until the phone is linked.</p>}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <button disabled={!link.linked || busyAction==="Launch FL Studio"} onClick={()=>runRemoteAction("Launch FL Studio","FL Studio", "Phone")} className="btn-ghost min-h-[56px] text-base disabled:opacity-40">Launch FL Studio</button>
                <button disabled={!link.linked || busyAction==="Focus FL Studio"} onClick={()=>runRemoteAction("Focus FL Studio","FL Studio","Phone")} className="btn-ghost min-h-[56px] text-base disabled:opacity-40">Focus FL Studio</button>
                <button disabled={!link.linked} onClick={()=>runRemoteAction("Play","Transport","Phone")} className="min-h-[56px] rounded-full bg-emerald-500 text-black font-bold text-base disabled:opacity-40 flex items-center justify-center gap-2"><Play size={19}/> Play</button>
                <button disabled={!link.linked} onClick={()=>runRemoteAction("Stop","Transport","Phone")} className="min-h-[56px] rounded-full bg-red-500 text-white font-bold text-base disabled:opacity-40 flex items-center justify-center gap-2"><Square size={17}/> Stop</button>
                <button disabled={!link.linked} onClick={()=>runRemoteAction("Record","Transport","Phone")} className="col-span-2 min-h-[56px] rounded-full bg-[#FF4757] text-white font-bold text-base disabled:opacity-40 flex items-center justify-center gap-2"><Mic size={18}/> ● Record</button>
              </div>
              <div className="grid gap-3 mt-3">
                <label className="block"><span className="text-sm text-[var(--muted)]">Open Project</span><select value={phoneOpenId} onChange={e=>setPhoneOpenId(e.target.value)} className="w-full mt-1 px-4 py-3.5 min-h-[52px]"><option value="">Choose a project…</option>{projects.map(p=><option key={p.id} value={p.id}>{p.title} • {p.key}</option>)}</select></label>
                <button disabled={!link.linked || !phoneOpenId} onClick={()=>{ const p=projects.find(x=>x.id===phoneOpenId); if(p) runRemoteAction("Open Project", p.title, "Phone"); }} className="btn-gold min-h-[52px] disabled:opacity-40">Open in FL Studio</button>
                <label className="block"><span className="text-sm text-[var(--muted)]">Import MIDI</span><select value={phoneMidiChoice} onChange={e=>setPhoneMidiChoice(e.target.value)} className="w-full mt-1 px-4 py-3.5 min-h-[52px]"><option>Current progression</option><option>Am7 – Fmaj7 – Cmaj7 – G7 (122 BPM)</option><option>Last generated progression</option></select></label>
                <button disabled={!link.linked} onClick={()=>runRemoteAction("Import MIDI", phoneMidiChoice, "Phone")} className="btn-ghost min-h-[52px] disabled:opacity-40">Import MIDI to FL Studio</button>
              </div>
              <p className="text-sm text-[var(--muted)] mt-3 flex gap-2"><Clock size={15} className="shrink-0 mt-0.5"/> Last action: {lastAction}</p>
            </section>

            <section className="card p-4 sm:p-5">
              <h2 className="font-bold text-xl flex items-center gap-2"><Music2 size={19} className="text-[#D7B36B]"/> 3 — QUICK MIDI FROM PHONE</h2>
              <p className="text-sm text-[var(--muted)] mt-1">Mini MIDI Studio — generated here appears in Desktop MIDI Studio too.</p>
              <div className="mt-3">{midiPanel(true)}</div>
            </section>
          </div>
        ) : (
          <div className="mt-4">
            <div className="flex gap-2 overflow-x-auto pb-1">{nav.map(n=>{ const Icon=n.icon; return <button key={n.id} onClick={()=>setTab(n.id)} className={`chip whitespace-nowrap min-h-[40px] flex items-center gap-2 ${tab===n.id?"active":""}`}><Icon size={16}/>{n.label}</button>})}</div>

            {tab==="dashboard" && (
              <div className="mt-4">
                <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="text-xs tracking-[.2em] text-[#D7B36B] font-semibold">LUKULU RECORDINGS — v0.5 BROWSER AGENT + MCP</p><h1 className="text-[clamp(1.8rem,4vw,3rem)] font-bold leading-[1.02] mt-2">NASTOR <span className="gold-text">AI STUDIO</span></h1><p className="text-[var(--muted)] mt-2">Desktop Studio + Phone Remote, linked. FL Studio: {flStatus} • {currentProject}</p></div><div className="flex gap-2"><button onClick={()=>setTab("midi")} className="btn-gold flex items-center gap-2 min-h-[44px]"><Music4 size={17}/> Generate Chords</button><button onClick={()=>setTab("projects")} className="btn-ghost flex items-center gap-2 min-h-[44px]"><Plus size={17}/> New Project</button></div></div>
                <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 mt-6">
                  {[["Active Projects", String(projects.length), "saved projects", FolderKanban],["Afro House BPM","122","house tempo",AudioLines],["Current Key","A Minor","signature key",Music2],["Bridge", link.simulate?"Simulate":"Live","FL Studio link",Radio]].map(([label,val,sub,Icon]:any)=><div key={label} className="card p-4 sm:p-5"><div className="flex justify-between"><span className="text-xs text-[var(--muted)]">{label}</span><Icon size={18} className="text-[#D7B36B]"/></div><div className="text-[clamp(1.5rem,3vw,2.1rem)] font-bold mt-2 [overflow-wrap:anywhere]">{val}</div><div className="text-xs text-[var(--muted-2)]">{sub}</div></div>)}
                </div>
                <div className="grid lg:grid-cols-5 gap-4 mt-4">
                  <div className="card p-5 lg:col-span-3"><div className="flex items-center justify-between"><h2 className="font-bold text-lg">Recent projects</h2><button onClick={()=>setTab("projects")} className="text-sm text-[#D7B36B]">View all →</button></div>{loading?<p className="text-sm text-[var(--muted)] mt-4">Loading saved projects…</p>:projects.length===0?<p className="text-sm text-[var(--muted)] mt-4">No saved projects yet. Add one from the starter examples below, or create your own.</p>:<div className="mt-3 divide-y divide-[var(--border)]">{projects.slice(0,4).map(p=><div key={p.id} className="py-3 flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-[var(--surface-3)] grid place-items-center text-[#D7B36B] font-bold">{p.title.slice(0,1)}</div><div className="min-w-0"><div className="font-semibold truncate [overflow-wrap:anywhere]">{p.title}</div><div className="text-xs text-[var(--muted)]">{p.key} • {p.bpm} BPM</div></div><span className="ml-auto text-xs px-2.5 py-1 rounded-full bg-[var(--surface-3)]">{p.status}</span></div>)}</div>}{loadError && <p className="text-xs text-[#FFB3B3] mt-3">{loadError}</p>}</div>
                  <div className="card p-5 lg:col-span-2 bg-gradient-to-br from-[#1A140A] to-[#12121A]"><div className="flex items-center gap-2 text-[#D7B36B] text-sm font-semibold"><Zap size={16}/> QUICK ACTIONS</div><div className="space-y-2 mt-4"><button onClick={()=>setTab("projects")} className="w-full text-left p-3 rounded-xl bg-[var(--surface)] border border-[var(--border)] flex justify-between min-h-[48px] items-center">New Project <Plus size={17}/></button><button onClick={()=>setTab("midi")} className="w-full text-left p-3 rounded-xl bg-[var(--surface)] border border-[var(--border)] flex justify-between min-h-[48px] items-center">Generate Chords <Music2 size={17}/></button><button onClick={()=>{setTab("connection");}} className="w-full text-left p-3 rounded-xl bg-[var(--surface)] border border-[var(--border)] flex justify-between min-h-[48px] items-center">Check Bridge <Radio size={17}/></button></div><div className="mt-4 p-3 rounded-xl bg-black/30 text-xs leading-relaxed text-[var(--muted)]">Today’s groove: Am7 – F – C – G at 122 BPM. Keep the kick 4-on-the-floor and let the log drum talk.</div></div>
                </div>
                <div className="card p-5 mt-4"><div className="flex items-center justify-between"><h2 className="font-bold text-lg flex items-center gap-2"><Smartphone size={18} className="text-[#D7B36B]"/> LIVE PROMPTS FROM PHONE</h2><button onClick={()=>setTab("assistant")} className="text-sm text-[#D7B36B]">Open Assistant →</button></div><div className="mt-4">{promptsFeed(true)}</div></div>
                <div className="mt-4">{agentPanel("Desktop","GOPHER AGENT — FULL-WIDTH CONSOLE")}</div>
                <div className="card p-5 mt-4"><h3 className="font-bold">Starter projects</h3><p className="text-sm text-[var(--muted)] mt-1">These examples are not saved yet — tap “Add” to save one to your projects.</p><div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3 mt-4">{EXAMPLES.map(e=><div key={e.title} className="p-4 rounded-xl border border-[var(--border)] bg-[var(--surface-2)]"><div className="font-semibold [overflow-wrap:anywhere]">{e.title}</div><div className="text-xs text-[var(--muted)] mt-1">{e.key} • {e.bpm} BPM • {e.status}</div><button disabled={saving} onClick={()=>addProject(undefined, e)} className="btn-ghost w-full mt-3 !py-2 text-sm min-h-[44px]">Add to my projects</button></div>)}</div>{saveMsg && <p className="text-sm text-emerald-300 mt-3">{saveMsg}</p>}</div>
              </div>
            )}

            {tab==="connection" && (
              <div className="mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">FL Studio Control</h1><p className="text-[var(--muted)] mt-1">Bridge is LAN only, token-protected, allowlisted actions only: launch, focus, play, stop, record, open-project, import-midi, list-projects.</p>
                <div className="grid lg:grid-cols-2 gap-4 mt-5">
                  <div className="card p-5"><div className="flex items-center gap-3"><span className={`w-3 h-3 rounded-full ${bridge==="online"?"bg-emerald-400":bridge==="checking"?"bg-amber-400 animate-pulse":"bg-red-500"}`}/><div><div className="font-bold text-lg">{bridge==="online"?"Bridge Online":bridge==="checking"?"Checking…":bridge==="offline"?"Bridge Offline":"Bridge status"}</div><div className="text-xs text-[var(--muted)] mono [overflow-wrap:anywhere]">{link.bridgeUrl}/status</div></div></div><p className="text-sm text-[var(--muted)] leading-relaxed mt-4">FL Studio is currently <b className="text-white">{flStatus}</b> • {currentProject}. Last action: {lastAction}</p>
                    <div className="grid grid-cols-2 gap-2 mt-4"><button onClick={()=>runRemoteAction("Launch FL Studio","FL Studio","Desktop")} className="btn-ghost min-h-[48px]">Launch FL Studio</button><button onClick={()=>runRemoteAction("Focus FL Studio","FL Studio","Desktop")} className="btn-ghost min-h-[48px]">Focus FL Studio</button><button onClick={()=>runRemoteAction("Play","Transport","Desktop")} className="min-h-[48px] rounded-full bg-emerald-500 text-black font-bold flex items-center justify-center gap-2"><Play size={17}/> Play</button><button onClick={()=>runRemoteAction("Stop","Transport","Desktop")} className="min-h-[48px] rounded-full bg-red-500 text-white font-bold flex items-center justify-center gap-2"><Square size={16}/> Stop</button><button onClick={()=>runRemoteAction("Record","Transport","Desktop")} className="col-span-2 min-h-[48px] rounded-full bg-[#FF4757] text-white font-bold flex items-center justify-center gap-2"><Mic size={17}/> Record</button></div>
                    <button onClick={checkBridge} disabled={bridge==="checking"} className="btn-gold mt-4 w-full min-h-[48px]">{bridge==="checking"?"Checking…":"Test Connection"}</button>
                    <div className="mt-5 space-y-3">
                      <label className="flex items-center justify-between p-3 rounded-xl border border-[var(--border)]"><span><span className="block font-semibold text-sm">Auto-connect</span><span className="text-xs text-[var(--muted)]">Try the bridge when the studio opens</span></span><button role="switch" aria-checked={autoConnect} onClick={()=>setAutoConnect(v=>!v)} className={`w-11 h-6 rounded-full p-1 transition ${autoConnect?"bg-[#D7B36B]":"bg-[#2A2A3A]"}`}><span className={`block w-4 h-4 rounded-full bg-white transition ${autoConnect?"translate-x-5":""}`}/></button></label>
                      <label className="flex items-center justify-between p-3 rounded-xl border border-[var(--border)]"><span><span className="block font-semibold text-sm">MIDI Clock Sync</span><span className="text-xs text-[var(--muted)]">Visual only in this prototype</span></span><button role="switch" aria-checked={clockSync} onClick={()=>setClockSync(v=>!v)} className={`w-11 h-6 rounded-full p-1 transition ${clockSync?"bg-[#D7B36B]":"bg-[#2A2A3A]"}`}><span className={`block w-4 h-4 rounded-full bg-white transition ${clockSync?"translate-x-5":""}`}/></button></label>
                    </div>
                  </div>
                  <div>
                    <div className="card p-5"><h3 className="font-bold flex items-center gap-2"><LinkIcon size={18}/> Pairing + Linked Phone</h3><div className="flex items-center gap-4 mt-3"><div className="mono text-3xl font-bold tracking-[.15em]">{link.pairingCode}</div><span className={`text-xs px-3 py-1.5 rounded-full font-bold ${link.linked?"bg-emerald-500/15 text-emerald-300":"bg-amber-500/10 text-amber-300"}`}>{link.linked?"Phone linked":"No phone linked"}</span></div><p className="text-sm text-[var(--muted)] mt-2">Bridge Token + URL are in the Link card at the top. Regenerating the code unlinks the phone.</p><button onClick={regenerateCode} className="btn-ghost mt-3 min-h-[44px] inline-flex items-center gap-2"><RefreshCw size={16}/> Regenerate pairing code</button></div>
                    <div className="card p-5 mt-4"><h3 className="font-bold">Remote action log — last 10</h3>{actionsLog.length===0?<p className="text-sm text-[var(--muted)] mt-2">No remote actions yet. Press Play from Desktop or Phone.</p>:<ul className="mt-3 space-y-2">{actionsLog.slice(0,10).map(a=><li key={a.id} className="flex flex-wrap gap-2 text-sm"><span className="font-semibold">{a.action}</span><span className="text-[var(--muted)] [overflow-wrap:anywhere]">{a.detail}</span><span className="ml-auto text-xs text-[var(--muted)]">{a.source} • {fmtTime(a.createdAt)}</span></li>)}</ul>}</div>
                    <div className="card p-5 mt-4"><h3 className="font-bold flex items-center gap-2"><Settings2 size={18}/> Connection steps — Mac</h3><ol className="mt-4 space-y-4">{[["1","Extract ZIP","Extract NASTOR_AI_STUDIO to your Downloads folder."],["2","Open the folder","In Terminal: cd ~/Downloads/NASTOR_AI_STUDIO"],["3","Start the bridge","cd desktop-bridge && npm install && npm start"]].map(([n,t,d])=><li key={n} className="flex gap-3"><span className="w-7 h-7 shrink-0 rounded-full bg-[#D7B36B] text-black grid place-items-center font-bold text-sm">{n}</span><span><span className="block font-semibold">{t}</span><span className="text-sm text-[var(--muted)] mono [overflow-wrap:anywhere]">{d}</span></span></li>)}</ol><div className="mt-5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm leading-relaxed flex gap-2"><CircleAlert size={18} className="shrink-0 text-amber-400"/> LAN only. Use Tailscale / VPN outside home. Never port-forward port 4317.</div></div>
                  </div>
                </div>
              </div>
            )}

            {tab==="midi" && (
              <div className="mt-4">
                <div className="flex flex-wrap justify-between gap-3 items-end"><div><h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">MIDI Studio</h1><p className="text-[var(--muted)]">Afro House chord progression • <span className="text-[#D7B36B]">Am – F – C – G energy</span></p></div><span className="mono text-xs px-3 py-1.5 rounded-full border border-[var(--border)]">122 BPM • A MINOR • AFRO HOUSE</span></div>
                <div className="mt-5">{midiPanel(false)}</div>
                <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3 mt-4">{chords.map((c,i)=><div key={i} className="card p-4 overflow-hidden"><div className="flex justify-between items-start"><span className="text-[11px] tracking-widest text-[var(--muted)]">CHORD {i+1} • {c.degree.toUpperCase()}</span><span className="w-7 h-7 rounded-full bg-[#D7B36B] text-black grid place-items-center"><Volume2 size={14}/></span></div><div className="text-[clamp(1.6rem,3vw,2rem)] font-bold mt-2">{c.name}</div><div className="mono text-xs text-[var(--muted)] [overflow-wrap:anywhere]">{c.noteNames.join("  •  ")}</div><div className="mt-4 space-y-1.5">{c.notes.map((n,j)=><div key={j} className="flex items-center gap-2"><span className="mono text-[10px] w-7 text-[var(--muted)]">{midiName(n)}</span><div className="flex-1 h-[14px] bg-white/5 rounded-md relative"><div className="piano-bar absolute top-0 h-full" style={{left:`${(n%12)/12*72}%`, width:"26%", background: j===0?"#D7B36B": j===1?"#E8C97F": j===2?"#FF6B35":"#8A6BFF"}}/></div></div>)}</div></div>)}</div>
                {arrangement && <div className="card p-5 mt-4"><h3 className="font-bold flex items-center gap-2"><ListMusic size={18} className="text-[#D7B36B]"/> Arrangement — {arrangement.title}</h3><div className="mt-3 space-y-2">{arrangement.sections.map((s,i)=><div key={i} className="flex gap-3 text-sm"><span className="mono text-xs text-[#D7B36B] w-20 shrink-0">{s.bars}</span><span><b>{s.name}</b><span className="text-[var(--muted)]"> — {s.detail}</span></span></div>)}</div><h4 className="font-bold mt-4">Mix Checklist</h4><div className="mt-2 space-y-2">{arrangement.mixTasks.map(t=><label key={t.id} className="flex gap-2.5 items-start text-sm p-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--border)] cursor-pointer"><input type="checkbox" checked={t.done} onChange={()=>toggleMixTask(t.id)} className="mt-0.5 w-4 h-4 accent-[#D7B36B]"/><span className={t.done?"line-through text-[var(--muted)]":"[overflow-wrap:anywhere]"}>{t.label}</span></label>)}</div></div>}
                {logDrum && <div className="card p-5 mt-4"><h3 className="font-bold flex items-center gap-2"><Drum size={18} className="text-[#D7B36B]"/> Afro House Drum Pattern</h3><div className="grid sm:grid-cols-3 gap-3 mt-4 text-sm"><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>Kick — 4-on-the-floor</b><div className="text-[var(--muted)] text-xs mt-1">Beats 1 • 2 • 3 • 4 — deep, steady, sidechained.</div><div className="mono text-[#D7B36B] mt-2">● &nbsp; ● &nbsp; ● &nbsp; ●</div></div><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>Shaker</b><div className="text-[var(--muted)] text-xs mt-1">Off-beat 8ths + 16th swing for movement.</div><div className="mono text-[#D7B36B] mt-2">· x · x · x · x</div></div><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>Clap</b><div className="text-[var(--muted)] text-xs mt-1">Beats 2 &amp; 4 — layered, slightly wide.</div><div className="mono text-[#FF6B35] mt-2">— ✦ — ✦</div></div></div>{drumPattern && <p className="text-sm text-[var(--muted)] mt-3 [overflow-wrap:anywhere]">{drumPattern}</p>}{bassline && <p className="text-sm text-[var(--muted)] mt-2 [overflow-wrap:anywhere]"><b className="text-white">Bassline:</b> {bassline}</p>}</div>}
                <p className="text-xs text-[var(--muted)] mt-3 flex items-center gap-1.5"><Headphones size={14}/> Play Preview uses Web Audio oscillators — no sample files needed. Download MIDI opens cleanly in FL Studio.</p>
              </div>
            )}

            {tab==="projects" && (
              <div className="mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">Projects</h1><p className="text-[var(--muted)] mt-1">Your ideas, saved in this studio. They stay saved after you reload.</p>
                <form onSubmit={addProject} className="card p-5 mt-5 grid sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end"><label className="block sm:col-span-2"><span className="text-xs text-[var(--muted)]">Title</span><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Midnight in Soweto" className="w-full mt-1.5 px-3 py-2.5"/></label><label className="block"><span className="text-xs text-[var(--muted)]">Key</span><select value={form.key} onChange={e=>setForm({...form,key:e.target.value})} className="w-full mt-1.5 px-3 py-2.5">{KEY_OPTIONS.map(k=><option key={k}>{k}</option>)}</select></label><label className="block"><span className="text-xs text-[var(--muted)]">BPM</span><input type="number" min={80} max={140} value={form.bpm} onChange={e=>setForm({...form,bpm:Number(e.target.value)})} className="w-full mt-1.5 px-3 py-2.5"/></label><label className="block"><span className="text-xs text-[var(--muted)]">Status</span><select value={form.status} onChange={e=>setForm({...form,status:e.target.value})} className="w-full mt-1.5 px-3 py-2.5"><option>Idea</option><option>In Progress</option><option>Mixing</option><option>Mastered</option></select></label><button disabled={saving} className="btn-gold flex items-center justify-center gap-2 sm:col-span-2 lg:col-span-1 min-h-[44px]"><Plus size={17}/>{saving?"Saving…":"Add Project"}</button></form>
                {saveMsg && <p className="text-sm mt-3 text-emerald-300">{saveMsg}</p>}
                <div className="flex flex-col sm:flex-row gap-2 mt-4"><div className="relative flex-1"><Search size={17} className="absolute left-3 top-3 text-[var(--muted)]"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search projects…" className="w-full pl-9 pr-3 py-2.5"/></div><div className="flex gap-2 overflow-x-auto">{["All","Idea","In Progress","Mixing","Mastered"].map(s=><button key={s} onClick={()=>setFilter(s)} className={`chip whitespace-nowrap ${filter===s?"active":""}`}>{s}</button>)}</div></div>
                <div className="mt-4">{loading?<p className="text-[var(--muted)]">Loading…</p>:filtered.length===0?<div className="card p-6 text-center"><p className="font-semibold">No projects match that view.</p><p className="text-sm text-[var(--muted)] mt-1">Try a different filter, or add a new project above.</p></div>:<div className="grid md:grid-cols-2 gap-3">{filtered.map(p=><article key={p.id} className="card p-4 flex gap-3"><div className="w-11 h-11 shrink-0 rounded-xl bg-gradient-to-br from-[#D7B36B] to-[#E8C97F] grid place-items-center text-black font-black">{p.title.slice(0,1)}</div><div className="min-w-0 flex-1"><div className="font-bold [overflow-wrap:anywhere]">{p.title}</div><div className="text-sm text-[var(--muted)]">{p.key} • {p.bpm} BPM</div><span className="inline-block mt-2 text-xs px-2 py-1 rounded-full bg-[var(--surface-3)]">{p.status}</span><div className="mt-3"><button onClick={()=>runRemoteAction("Open Project", p.title, "Desktop")} className="btn-ghost !py-2 px-3 text-sm inline-flex items-center gap-2"><Play size={14}/> Open in FL Studio</button></div></div><button onClick={()=>deleteProject(p.id)} disabled={deleting===p.id} aria-label={`Delete ${p.title}`} className="self-start p-2 rounded-lg border border-[var(--border)] hover:border-red-400 text-[var(--muted)] hover:text-red-300"><Trash2 size={17}/></button></article>)}</div>}</div>
                {loadError && <p className="text-xs text-[#FFB3B3] mt-3">{loadError}</p>}
                <p className="text-xs text-[var(--muted-2)] mt-4">Storage limit: this studio shares 1,000 saved records across the whole app. Keep projects small and focused.</p>
              </div>
            )}

            {tab==="browser" && (
              <div className="mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">Browser Agent (MCP)</h1><p className="text-[var(--muted)] mt-1">Browser-Use MCP — the browser-control layer for the Gopher-style agent. FL Studio: {flStatus} • {currentProject}</p>
                <div className="mt-4">{browserPanel("Desktop")}</div>
              </div>
            )}

            {tab==="mixer" && (
              <div className="mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">Remote Mixer &amp; Arrange</h1><p className="text-[var(--muted)] mt-1">Everything your phone can control, here too — mix, sound design, arrangement, and transport. FL Studio: {flStatus} • {currentProject}</p>
                <div className="mt-4 space-y-4">{mixerPanel("Desktop")}{arrangementEditor("Desktop")}
                  <section className="card p-4 sm:p-5"><h2 className="font-bold text-xl flex items-center gap-2"><Radio size={19} className="text-[#D7B36B]"/> Remote Transport</h2><p className="text-sm text-[var(--muted)] mt-1">Same allowlisted controls the phone uses.</p><div className="flex flex-wrap gap-2 mt-3"><button onClick={()=>runRemoteAction("Launch FL Studio","FL Studio","Desktop")} className="btn-ghost min-h-[48px]">Launch FL Studio</button><button onClick={()=>runRemoteAction("Play","Transport","Desktop")} className="min-h-[48px] rounded-full bg-emerald-500 text-black font-bold px-5 flex items-center gap-2"><Play size={17}/> Play</button><button onClick={()=>runRemoteAction("Stop","Transport","Desktop")} className="min-h-[48px] rounded-full bg-red-500 text-white font-bold px-5 flex items-center gap-2"><Square size={16}/> Stop</button><button onClick={()=>runRemoteAction("Record","Transport","Desktop")} className="min-h-[48px] rounded-full bg-[#FF4757] text-white font-bold px-5 flex items-center gap-2"><Mic size={17}/> Record</button></div><p className="text-sm text-[var(--muted)] mt-3">Last action: {lastAction}</p></section>
                </div>
              </div>
            )}

            {tab==="assistant" && (
              <div className="max-w-[860px] mx-auto mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">Production Assistant</h1><p className="text-[var(--muted)] mt-1">Afro House ideas for DJ Nastor • Lukulu Recordings</p>
                <div className="card p-5 mt-4"><h2 className="font-bold flex items-center gap-2"><Smartphone size={18} className="text-[#D7B36B]"/> LIVE PROMPTS FROM PHONE</h2><div className="mt-3">{promptsFeed(true)}</div><button onClick={()=>setMode("phone")} className="btn-ghost mt-3 min-h-[44px]">Open Phone Remote →</button></div>
                <div className="mt-4">{agentPanel("Desktop","GOPHER AGENT")}</div>
                <div className="flex flex-wrap gap-2 mt-4">{ASSISTANT_CHIPS.map(c=><button key={c} onClick={()=>sendPrompt(c)} className="chip text-left">{c}</button>)}</div>
                <div className="card mt-4 p-4 sm:p-5 min-h-[340px] max-h-[520px] overflow-y-auto space-y-3">{chat.map((m,i)=><div key={i} className={`flex ${m.role==="user"?"justify-end":"justify-start"}`}><div className={`max-w-[86%] px-4 py-3 rounded-2xl text-sm leading-relaxed [overflow-wrap:anywhere] ${m.role==="user"?"bg-[#D7B36B] text-black font-medium rounded-br-md":"bg-[var(--surface-2)] border border-[var(--border)] rounded-bl-md"}`}>{m.text}</div></div>)}<div id="chat-end"/></div>
                <form onSubmit={e=>{e.preventDefault(); sendPrompt();}} className="flex gap-2 mt-3"><input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Ask about chords, log drums, arrangement…" className="flex-1 px-4 py-3"/><button className="btn-gold px-5 min-h-[48px]">Send</button></form>
                <p className="text-xs text-[var(--muted-2)] mt-2">Starter prompts give instant, practical answers — no account or connection needed.</p>
              </div>
            )}

            {tab==="install" && (
              <div className="mt-4">
                <h1 className="text-[clamp(1.6rem,3.5vw,2.4rem)] font-bold">Bridge / Install</h1><p className="text-[var(--muted)] mt-1">MacBook Pro • macOS Catalina 10.15.7 • NASTOR AI STUDIO v0.3 INTELLIGENT AGENT</p>
                <div className="grid lg:grid-cols-2 gap-4 mt-5">
                  <div className="card p-5"><div className="flex items-center gap-2 font-bold"><TerminalSquare size={18} className="text-[#D7B36B]"/> 1 — Open the studio</div><p className="text-sm text-[var(--muted)] mt-2">From your extracted Downloads folder:</p><pre className="mono text-[13px] leading-relaxed bg-black/40 border border-[var(--border)] rounded-xl p-4 mt-3 overflow-x-auto whitespace-pre-wrap [overflow-wrap:anywhere]">cd ~/Downloads/NASTOR_AI_STUDIO{"\n"}open index.html</pre><p className="text-xs text-[var(--muted)] mt-3">This opens the dashboard in your default browser. You can use the MIDI Studio immediately.</p></div>
                  <div className="card p-5"><div className="flex items-center gap-2 font-bold"><Radio size={18} className="text-[#D7B36B]"/> 2 — Start the desktop bridge</div><p className="text-sm text-[var(--muted)] mt-2">The bridge needs Node.js installed. LAN only, port 4317:</p><pre className="mono text-[13px] leading-relaxed bg-black/40 border border-[var(--border)] rounded-xl p-4 mt-3 overflow-x-auto whitespace-pre-wrap [overflow-wrap:anywhere]">cd ~/Downloads/NASTOR_AI_STUDIO/desktop-bridge{"\n"}npm install{"\n"}npm start</pre><p className="text-xs text-[var(--muted)] mt-3">You should see: <span className="mono text-white">NASTOR bridge listening at http://127.0.0.1:4317</span></p></div>
                </div>
                <div className="card p-5 mt-4"><h3 className="font-bold flex items-center gap-2"><CheckCircle2 size={18} className="text-emerald-400"/> Compatibility</h3><p className="text-sm text-[var(--muted)] leading-relaxed mt-2">Targeted for macOS Catalina 10.15.7, with macOS 10.13+ as the compatibility target. Phone and Mac must be on the same WiFi. Outside home, use Tailscale / VPN — never port-forward 4317.</p><div className="grid sm:grid-cols-3 gap-3 mt-4 text-sm"><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>What’s working</b><div className="text-xs text-[var(--muted)] mt-1">Dashboard, FL control, MIDI Studio, projects, assistant, bridge status, phone pairing + remote, intelligent agent.</div></div><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>Not yet</b><div className="text-xs text-[var(--muted)] mt-1">Real bridge still needs the Node bridge running on the Mac. Simulate Bridge covers demo.</div></div><div className="p-3 rounded-xl bg-[var(--surface-2)]"><b>Next stage</b><div className="text-xs text-[var(--muted)] mt-1">Native desktop control, AI integration, Windows / macOS installers.</div></div></div></div>
                <p className="text-xs text-[var(--muted-2)] mt-3">Tip: select any command above to copy it into Terminal. The ZIP must first be extracted into Downloads.</p>
              </div>
            )}
          </div>
        )}

        <footer className="border-t border-[var(--border)] mt-10 pt-4 pb-6 flex flex-wrap gap-2 justify-between text-xs text-[var(--muted-2)]"><span>NASTOR AI STUDIO • Version 0.5 BROWSER AGENT + MCP • Prototype</span><span>DJ Nastor • Lukulu Recordings • Afro House</span><span>LAN only • Token required • Allowlist only • Do not port-forward 4317</span></footer>
      </main>
    </div>
  );
}
